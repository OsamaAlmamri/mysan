<!-- Banners Content -->
<section class="banners-content">

  <?php  echo $final_theme['banner']; ?>

</section>
