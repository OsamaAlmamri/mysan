<?php
return
    ['previous' => '&laquo; السابق',
        'next' => 'التالي &raquo;',

       ];
