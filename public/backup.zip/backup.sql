TRUNCATE address_book; TRUNCATE alert_settings; INSERT INTO alert_settings (`alert_id`, `create_customer_email`, `create_customer_notification`, `order_status_email`, `order_status_notification`, `new_product_email`, `new_product_notification`, `forgot_email`, `forgot_notification`, `news_email`, `news_notification`, `contact_us_email`, `contact_us_notification`, `order_email`, `order_notification`); VALUES ('1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');


TRUNCATE api_calls_list; TRUNCATE banners; TRUNCATE banners_history; TRUNCATE block_ips; TRUNCATE categories; TRUNCATE categories_description; TRUNCATE categories_role; TRUNCATE compare; TRUNCATE constant_banners; INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('1', 'style0', '', '114', '2019-09-08 18:43:14', '1', '1', '1');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('2', 'style0', '', '114', '2019-09-08 18:43:25', '1', '1', '2');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('3', 'banner1', '', '83', '2019-09-08 18:43:34', '1', '1', '3');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('4', 'banner1', '', '83', '2019-09-08 18:43:42', '1', '1', '4');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('5', 'banner1', '', '83', '2019-09-08 18:44:15', '1', '1', '5');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('6', 'banner2_3_4', '', '84', '2019-09-10 08:50:55', '1', '1', '6');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('7', 'banner2_3_4', '', '85', '2019-09-10 08:54:18', '1', '1', '7');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('8', 'banner2_3_4', '', '86', '2019-09-10 08:54:28', '1', '1', '8');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('9', 'banner2_3_4', '', '86', '2019-09-10 08:54:38', '1', '1', '9');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('10', 'banner5_6', '', '92', '2019-09-10 09:31:13', '1', '1', '10');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('11', 'banner5_6', '', '92', '2019-09-10 09:31:24', '1', '1', '11');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('12', 'banner5_6', '', '92', '2019-09-10 09:31:35', '1', '1', '12');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('13', 'banner5_6', '', '92', '2019-09-10 09:32:18', '1', '1', '13');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('14', 'banner5_6', '', '91', '2019-09-10 09:32:28', '1', '1', '14');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('15', 'banner7_8', '', '95', '2019-09-10 09:52:02', '1', '1', '15');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('16', 'banner7_8', '', '96', '2019-09-10 09:52:29', '1', '1', '16');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('17', 'banner7_8', '', '96', '2019-09-10 09:47:56', '1', '1', '17');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('18', 'banner7_8', '', '94', '2019-09-10 09:48:05', '1', '1', '18');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('19', 'banner9', '', '97', '2019-09-10 10:19:03', '1', '1', '19');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('20', 'banner9', '', '97', '2019-09-10 10:19:13', '1', '1', '20');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('21', 'banner10_11_12', '', '98', '2019-09-10 10:26:12', '1', '1', '21');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('22', 'banner10_11_12', '', '96', '2019-09-10 10:26:30', '1', '1', '22');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('23', 'banner10_11_12', '', '96', '2019-09-10 10:26:41', '1', '1', '23');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('24', 'banner10_11_12', '', '99', '2019-09-10 10:26:54', '1', '1', '24');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('25', 'banner13_14_15', '', '100', '2019-09-10 11:01:09', '1', '1', '25');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('26', 'banner13_14_15', '', '101', '2019-09-10 11:01:27', '1', '1', '26');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('27', 'banner13_14_15', '', '101', '2019-09-10 11:02:12', '1', '1', '27');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('28', 'banner13_14_15', '', '101', '2019-09-10 11:02:23', '1', '1', '28');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('29', 'banner13_14_15', '', '101', '2019-09-10 11:02:36', '1', '1', '29');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('30', 'banner16_17', '', '104', '2019-09-10 11:19:45', '1', '1', '30');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('31', 'banner16_17', '', '104', '2019-09-10 11:19:58', '1', '1', '31');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('32', 'banner16_17', '', '105', '2019-09-10 11:21:00', '1', '1', '32');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('33', 'banner18_19', '', '116', '2019-09-10 11:30:35', '1', '1', '33');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('34', 'banner18_19', '', '116', '2019-09-10 11:30:49', '1', '1', '34');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('35', 'banner18_19', '', '96', '2019-09-10 11:31:04', '1', '1', '35');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('36', 'banner18_19', '', '96', '2019-09-10 11:31:20', '1', '1', '36');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('37', 'banner18_19', '', '115', '2019-09-10 11:31:54', '1', '1', '37');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('38', 'banner18_19', '', '115', '2019-09-10 11:32:06', '1', '1', '38');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('39', 'ad_banner1', '', '107', '2019-09-11 06:17:45', '1', '1', '39');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('40', 'ad_banner2', '', '106', '2019-09-11 06:17:58', '1', '1', '40');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('41', 'style0', '', '114', '0000-00-00 00:00:00', '1', '2', '1');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('42', 'style0', '', '114', '0000-00-00 00:00:00', '1', '2', '2');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('43', 'banner1', '', '83', '0000-00-00 00:00:00', '1', '2', '3');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('44', 'banner1', '', '83', '0000-00-00 00:00:00', '1', '2', '4');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('45', 'banner1', '', '83', '0000-00-00 00:00:00', '1', '2', '5');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('46', 'banner2_3_4', '', '84', '0000-00-00 00:00:00', '1', '2', '6');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('47', 'banner2_3_4', '', '85', '0000-00-00 00:00:00', '1', '2', '7');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('48', 'banner2_3_4', '', '86', '0000-00-00 00:00:00', '1', '2', '8');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('49', 'banner2_3_4', '', '86', '0000-00-00 00:00:00', '1', '2', '9');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('50', 'banner5_6', '', '92', '0000-00-00 00:00:00', '1', '2', '10');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('51', 'banner5_6', '', '92', '0000-00-00 00:00:00', '1', '2', '11');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('52', 'banner5_6', '', '92', '0000-00-00 00:00:00', '1', '2', '12');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('53', 'banner5_6', '', '92', '0000-00-00 00:00:00', '1', '2', '13');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('54', 'banner5_6', '', '91', '0000-00-00 00:00:00', '1', '2', '14');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('55', 'banner7_8', '', '95', '0000-00-00 00:00:00', '1', '2', '15');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('56', 'banner7_8', '', '96', '0000-00-00 00:00:00', '1', '2', '16');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('57', 'banner7_8', '', '96', '0000-00-00 00:00:00', '1', '2', '17');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('58', 'banner7_8', '', '94', '0000-00-00 00:00:00', '1', '2', '18');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('59', 'banner9', '', '97', '0000-00-00 00:00:00', '1', '2', '19');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('60', 'banner9', '', '97', '0000-00-00 00:00:00', '1', '2', '20');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('61', 'banner10_11_12', '', '98', '0000-00-00 00:00:00', '1', '2', '21');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('62', 'banner10_11_12', '', '96', '0000-00-00 00:00:00', '1', '2', '22');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('63', 'banner10_11_12', '', '96', '0000-00-00 00:00:00', '1', '2', '23');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('64', 'banner10_11_12', '', '99', '0000-00-00 00:00:00', '1', '2', '24');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('65', 'banner13_14_15', '', '100', '0000-00-00 00:00:00', '1', '2', '25');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('66', 'banner13_14_15', '', '101', '0000-00-00 00:00:00', '1', '2', '26');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('67', 'banner13_14_15', '', '101', '0000-00-00 00:00:00', '1', '2', '27');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('68', 'banner13_14_15', '', '101', '0000-00-00 00:00:00', '1', '2', '28');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('69', 'banner13_14_15', '', '101', '0000-00-00 00:00:00', '1', '2', '29');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('70', 'banner16_17', '', '104', '0000-00-00 00:00:00', '1', '2', '30');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('71', 'banner16_17', '', '104', '0000-00-00 00:00:00', '1', '2', '31');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('72', 'banner16_17', '', '105', '0000-00-00 00:00:00', '1', '2', '32');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('73', 'banner18_19', '', '116', '0000-00-00 00:00:00', '1', '2', '33');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('74', 'banner18_19', '', '116', '0000-00-00 00:00:00', '1', '2', '34');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('75', 'banner18_19', '', '96', '0000-00-00 00:00:00', '1', '2', '35');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('76', 'banner18_19', '', '96', '0000-00-00 00:00:00', '1', '2', '36');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('77', 'banner18_19', '', '115', '0000-00-00 00:00:00', '1', '2', '37');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('78', 'banner18_19', '', '115', '0000-00-00 00:00:00', '1', '2', '38');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('79', 'ad_banner1', '', '107', '0000-00-00 00:00:00', '1', '2', '39');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('80', 'ad_banner2', '', '106', '0000-00-00 00:00:00', '1', '2', '40');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('81', 'ad_banner3', '', '107', '0000-00-00 00:00:00', '1', '1', '41');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('82', 'ad_banner3', '', '107', '0000-00-00 00:00:00', '1', '2', '41');


TRUNCATE countries; INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('1', 'Afghanistan', 'AF', 'AFG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('2', 'Albania', 'AL', 'ALB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('3', 'Algeria', 'DZ', 'DZA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('4', 'American Samoa', 'AS', 'ASM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('5', 'Andorra', 'AD', 'AND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('6', 'Angola', 'AO', 'AGO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('7', 'Anguilla', 'AI', 'AIA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('8', 'Antarctica', 'AQ', 'ATA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('9', 'Antigua and Barbuda', 'AG', 'ATG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('10', 'Argentina', 'AR', 'ARG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('11', 'Armenia', 'AM', 'ARM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('12', 'Aruba', 'AW', 'ABW', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('13', 'Australia', 'AU', 'AUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('14', 'Austria', 'AT', 'AUT', '5', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('15', 'Azerbaijan', 'AZ', 'AZE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('16', 'Bahamas', 'BS', 'BHS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('17', 'Bahrain', 'BH', 'BHR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('18', 'Bangladesh', 'BD', 'BGD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('19', 'Barbados', 'BB', 'BRB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('20', 'Belarus', 'BY', 'BLR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('21', 'Belgium', 'BE', 'BEL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('22', 'Belize', 'BZ', 'BLZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('23', 'Benin', 'BJ', 'BEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('24', 'Bermuda', 'BM', 'BMU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('25', 'Bhutan', 'BT', 'BTN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('26', 'Bolivia', 'BO', 'BOL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('27', 'Bosnia and Herzegowina', 'BA', 'BIH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('28', 'Botswana', 'BW', 'BWA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('29', 'Bouvet Island', 'BV', 'BVT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('30', 'Brazil', 'BR', 'BRA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('31', 'British Indian Ocean Territory', 'IO', 'IOT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('32', 'Brunei Darussalam', 'BN', 'BRN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('33', 'Bulgaria', 'BG', 'BGR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('34', 'Burkina Faso', 'BF', 'BFA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('35', 'Burundi', 'BI', 'BDI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('36', 'Cambodia', 'KH', 'KHM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('37', 'Cameroon', 'CM', 'CMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('38', 'Canada', 'CA', 'CAN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('39', 'Cape Verde', 'CV', 'CPV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('40', 'Cayman Islands', 'KY', 'CYM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('41', 'Central African Republic', 'CF', 'CAF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('42', 'Chad', 'TD', 'TCD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('43', 'Chile', 'CL', 'CHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('44', 'China', 'CN', 'CHN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('45', 'Christmas Island', 'CX', 'CXR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('46', 'Cocos (Keeling) Islands', 'CC', 'CCK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('47', 'Colombia', 'CO', 'COL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('48', 'Comoros', 'KM', 'COM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('49', 'Congo', 'CG', 'COG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('50', 'Cook Islands', 'CK', 'COK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('51', 'Costa Rica', 'CR', 'CRI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('52', 'Cote D\'Ivoire', 'CI', 'CIV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('53', 'Croatia', 'HR', 'HRV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('54', 'Cuba', 'CU', 'CUB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('55', 'Cyprus', 'CY', 'CYP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('56', 'Czech Republic', 'CZ', 'CZE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('57', 'Denmark', 'DK', 'DNK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('58', 'Djibouti', 'DJ', 'DJI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('59', 'Dominica', 'DM', 'DMA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('60', 'Dominican Republic', 'DO', 'DOM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('61', 'East Timor', 'TP', 'TMP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('62', 'Ecuador', 'EC', 'ECU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('63', 'Egypt', 'EG', 'EGY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('64', 'El Salvador', 'SV', 'SLV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('65', 'Equatorial Guinea', 'GQ', 'GNQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('66', 'Eritrea', 'ER', 'ERI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('67', 'Estonia', 'EE', 'EST', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('68', 'Ethiopia', 'ET', 'ETH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('69', 'Falkland Islands (Malvinas)', 'FK', 'FLK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('70', 'Faroe Islands', 'FO', 'FRO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('71', 'Fiji', 'FJ', 'FJI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('72', 'Finland', 'FI', 'FIN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('73', 'France', 'FR', 'FRA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('74', 'France, Metropolitan', 'FX', 'FXX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('75', 'French Guiana', 'GF', 'GUF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('76', 'French Polynesia', 'PF', 'PYF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('77', 'French Southern Territories', 'TF', 'ATF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('78', 'Gabon', 'GA', 'GAB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('79', 'Gambia', 'GM', 'GMB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('80', 'Georgia', 'GE', 'GEO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('81', 'Germany', 'DE', 'DEU', '5', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('82', 'Ghana', 'GH', 'GHA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('83', 'Gibraltar', 'GI', 'GIB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('84', 'Greece', 'GR', 'GRC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('85', 'Greenland', 'GL', 'GRL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('86', 'Grenada', 'GD', 'GRD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('87', 'Guadeloupe', 'GP', 'GLP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('88', 'Guam', 'GU', 'GUM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('89', 'Guatemala', 'GT', 'GTM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('90', 'Guinea', 'GN', 'GIN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('91', 'Guinea-bissau', 'GW', 'GNB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('92', 'Guyana', 'GY', 'GUY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('93', 'Haiti', 'HT', 'HTI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('94', 'Heard and Mc Donald Islands', 'HM', 'HMD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('95', 'Honduras', 'HN', 'HND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('96', 'Hong Kong', 'HK', 'HKG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('97', 'Hungary', 'HU', 'HUN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('98', 'Iceland', 'IS', 'ISL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('99', 'India', 'IN', 'IND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('100', 'Indonesia', 'ID', 'IDN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('101', 'Iran (Islamic Republic of)', 'IR', 'IRN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('102', 'Iraq', 'IQ', 'IRQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('103', 'Ireland', 'IE', 'IRL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('104', 'Israel', 'IL', 'ISR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('105', 'Italy', 'IT', 'ITA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('106', 'Jamaica', 'JM', 'JAM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('107', 'Japan', 'JP', 'JPN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('108', 'Jordan', 'JO', 'JOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('109', 'Kazakhstan', 'KZ', 'KAZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('110', 'Kenya', 'KE', 'KEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('111', 'Kiribati', 'KI', 'KIR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('112', 'Korea, Democratic People\'s Republic of', 'KP', 'PRK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('113', 'Korea, Republic of', 'KR', 'KOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('114', 'Kuwait', 'KW', 'KWT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('115', 'Kyrgyzstan', 'KG', 'KGZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('116', 'Lao People\'s Democratic Republic', 'LA', 'LAO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('117', 'Latvia', 'LV', 'LVA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('118', 'Lebanon', 'LB', 'LBN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('119', 'Lesotho', 'LS', 'LSO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('120', 'Liberia', 'LR', 'LBR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('121', 'Libyan Arab Jamahiriya', 'LY', 'LBY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('122', 'Liechtenstein', 'LI', 'LIE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('123', 'Lithuania', 'LT', 'LTU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('124', 'Luxembourg', 'LU', 'LUX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('125', 'Macau', 'MO', 'MAC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('126', 'Macedonia, The Former Yugoslav Republic of', 'MK', 'MKD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('127', 'Madagascar', 'MG', 'MDG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('128', 'Malawi', 'MW', 'MWI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('129', 'Malaysia', 'MY', 'MYS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('130', 'Maldives', 'MV', 'MDV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('131', 'Mali', 'ML', 'MLI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('132', 'Malta', 'MT', 'MLT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('133', 'Marshall Islands', 'MH', 'MHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('134', 'Martinique', 'MQ', 'MTQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('135', 'Mauritania', 'MR', 'MRT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('136', 'Mauritius', 'MU', 'MUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('137', 'Mayotte', 'YT', 'MYT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('138', 'Mexico', 'MX', 'MEX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('139', 'Micronesia, Federated States of', 'FM', 'FSM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('140', 'Moldova, Republic of', 'MD', 'MDA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('141', 'Monaco', 'MC', 'MCO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('142', 'Mongolia', 'MN', 'MNG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('143', 'Montserrat', 'MS', 'MSR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('144', 'Morocco', 'MA', 'MAR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('145', 'Mozambique', 'MZ', 'MOZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('146', 'Myanmar', 'MM', 'MMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('147', 'Namibia', 'NA', 'NAM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('148', 'Nauru', 'NR', 'NRU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('149', 'Nepal', 'NP', 'NPL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('150', 'Netherlands', 'NL', 'NLD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('151', 'Netherlands Antilles', 'AN', 'ANT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('152', 'New Caledonia', 'NC', 'NCL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('153', 'New Zealand', 'NZ', 'NZL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('154', 'Nicaragua', 'NI', 'NIC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('155', 'Niger', 'NE', 'NER', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('156', 'Nigeria', 'NG', 'NGA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('157', 'Niue', 'NU', 'NIU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('158', 'Norfolk Island', 'NF', 'NFK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('159', 'Northern Mariana Islands', 'MP', 'MNP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('160', 'Norway', 'NO', 'NOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('161', 'Oman', 'OM', 'OMN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('162', 'Pakistan', 'PK', 'PAK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('163', 'Palau', 'PW', 'PLW', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('164', 'Panama', 'PA', 'PAN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('165', 'Papua New Guinea', 'PG', 'PNG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('166', 'Paraguay', 'PY', 'PRY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('167', 'Peru', 'PE', 'PER', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('168', 'Philippines', 'PH', 'PHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('169', 'Pitcairn', 'PN', 'PCN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('170', 'Poland', 'PL', 'POL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('171', 'Portugal', 'PT', 'PRT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('172', 'Puerto Rico', 'PR', 'PRI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('173', 'Qatar', 'QA', 'QAT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('174', 'Reunion', 'RE', 'REU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('175', 'Romania', 'RO', 'ROM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('176', 'Russian Federation', 'RU', 'RUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('177', 'Rwanda', 'RW', 'RWA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('178', 'Saint Kitts and Nevis', 'KN', 'KNA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('179', 'Saint Lucia', 'LC', 'LCA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('180', 'Saint Vincent and the Grenadines', 'VC', 'VCT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('181', 'Samoa', 'WS', 'WSM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('182', 'San Marino', 'SM', 'SMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('183', 'Sao Tome and Principe', 'ST', 'STP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('184', 'Saudi Arabia', 'SA', 'SAU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('185', 'Senegal', 'SN', 'SEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('186', 'Seychelles', 'SC', 'SYC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('187', 'Sierra Leone', 'SL', 'SLE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('188', 'Singapore', 'SG', 'SGP', '4', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('189', 'Slovakia (Slovak Republic)', 'SK', 'SVK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('190', 'Slovenia', 'SI', 'SVN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('191', 'Solomon Islands', 'SB', 'SLB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('192', 'Somalia', 'SO', 'SOM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('193', 'South Africa', 'ZA', 'ZAF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('194', 'South Georgia and the South Sandwich Islands', 'GS', 'SGS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('195', 'Spain', 'ES', 'ESP', '3', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('196', 'Sri Lanka', 'LK', 'LKA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('197', 'St. Helena', 'SH', 'SHN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('198', 'St. Pierre and Miquelon', 'PM', 'SPM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('199', 'Sudan', 'SD', 'SDN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('200', 'Suriname', 'SR', 'SUR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('201', 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('202', 'Swaziland', 'SZ', 'SWZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('203', 'Sweden', 'SE', 'SWE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('204', 'Switzerland', 'CH', 'CHE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('205', 'Syrian Arab Republic', 'SY', 'SYR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('206', 'Taiwan', 'TW', 'TWN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('207', 'Tajikistan', 'TJ', 'TJK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('208', 'Tanzania, United Republic of', 'TZ', 'TZA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('209', 'Thailand', 'TH', 'THA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('210', 'Togo', 'TG', 'TGO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('211', 'Tokelau', 'TK', 'TKL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('212', 'Tonga', 'TO', 'TON', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('213', 'Trinidad and Tobago', 'TT', 'TTO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('214', 'Tunisia', 'TN', 'TUN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('215', 'Turkey', 'TR', 'TUR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('216', 'Turkmenistan', 'TM', 'TKM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('217', 'Turks and Caicos Islands', 'TC', 'TCA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('218', 'Tuvalu', 'TV', 'TUV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('219', 'Uganda', 'UG', 'UGA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('220', 'Ukraine', 'UA', 'UKR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('221', 'United Arab Emirates', 'AE', 'ARE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('222', 'United Kingdom', 'GB', 'GBR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('223', 'United States', 'US', 'USA', '2', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('224', 'United States Minor Outlying Islands', 'UM', 'UMI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('225', 'Uruguay', 'UY', 'URY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('226', 'Uzbekistan', 'UZ', 'UZB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('227', 'Vanuatu', 'VU', 'VUT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('228', 'Vatican City State (Holy See)', 'VA', 'VAT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('229', 'Venezuela', 'VE', 'VEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('230', 'Viet Nam', 'VN', 'VNM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('231', 'Virgin Islands (British)', 'VG', 'VGB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('232', 'Virgin Islands (U.S.)', 'VI', 'VIR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('233', 'Wallis and Futuna Islands', 'WF', 'WLF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('234', 'Western Sahara', 'EH', 'ESH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('235', 'Yemen', 'YE', 'YEM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('236', 'Yugoslavia', 'YU', 'YUG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('237', 'Zaire', 'ZR', 'ZAR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('238', 'Zambia', 'ZM', 'ZMB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('239', 'Zimbabwe', 'ZW', 'ZWE', '1', '');


TRUNCATE coupons; INSERT INTO coupons (`coupans_id`, `code`, `date_created`, `date_modified`, `description`, `discount_type`, `amount`, `expiry_date`, `usage_count`, `individual_use`, `product_ids`, `exclude_product_ids`, `usage_limit`, `usage_limit_per_user`, `limit_usage_to_x_items`, `free_shipping`, `product_categories`, `excluded_product_categories`, `exclude_sale_items`, `minimum_amount`, `maximum_amount`, `email_restrictions`, `used_by`, `created_at`, `updated_at`); VALUES ('1', '748', '', '', '', 'fixed_cart', '0', '2020-05-05 00:00:00', '0', '1', '', '', '1', '1', '0', '1', '', '', '1', '1.00', '10.00', '', '', '2020-05-28 01:58:37', '');


TRUNCATE currencies; INSERT INTO currencies (`id`, `title`, `code`, `symbol_left`, `symbol_right`, `decimal_point`, `thousands_point`, `decimal_places`, `created_at`, `updated_at`, `value`, `is_default`, `status`, `is_current`); VALUES ('1', 'U.S. Dollar', 'USD', '$', '', '', '', '2', '2019-09-06 18:33:11', '2019-09-06 18:33:11', '1', '1', '1', '1');


INSERT INTO currencies (`id`, `title`, `code`, `symbol_left`, `symbol_right`, `decimal_point`, `thousands_point`, `decimal_places`, `created_at`, `updated_at`, `value`, `is_default`, `status`, `is_current`); VALUES ('9', 'AED', 'AED', 'د.إ', '', '', '', '2', '2019-10-11 22:09:42', '2019-10-11 22:09:42', '3.67', '0', '1', '1');


TRUNCATE currency_record; INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('1', 'AED', 'United Arab Emirates Dirham');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('2', 'AFN', 'Afghan Afghani');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('3', 'ALL', 'Albanian Lek');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('4', 'AMD', 'Armenian Dram');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('5', 'ANG', 'Netherlands Antillean Guilder');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('6', 'AOA', 'Angolan Kwanza');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('7', 'ARS', 'Argentine Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('8', 'AUD', 'Australian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('9', 'AWG', 'Aruban Florin');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('10', 'AZN', 'Azerbaijani Manat');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('11', 'BAM', 'Bosnia-Herzegovina Convertible Mark');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('12', 'BBD', 'Barbadian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('13', 'BDT', 'Bangladeshi Taka');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('14', 'BGN', 'Bulgarian Lev');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('15', 'BHD', 'Bahraini Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('16', 'BIF', 'Burundian Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('17', 'BMD', 'Bermudan Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('18', 'BND', 'Brunei Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('19', 'BOB', 'Bolivian Boliviano');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('20', 'BRL', 'Brazilian Real');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('21', 'BSD', 'Bahamian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('22', 'BTC', 'Bitcoin');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('23', 'BTN', 'Bhutanese Ngultrum');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('24', 'BWP', 'Botswanan Pula');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('25', 'BYN', 'Belarusian Ruble');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('26', 'BZD', 'Belize Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('27', 'CAD', 'Canadian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('28', 'CDF', 'Congolese Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('29', 'CHF', 'Swiss Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('30', 'CLF', 'Chilean Unit of Account (UF)');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('31', 'CLP', 'Chilean Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('32', 'CNH', 'Chinese Yuan (Offshore)');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('33', 'CNY', 'Chinese Yuan');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('34', 'COP', 'Colombian Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('35', 'CRC', 'Costa Rican Colón');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('36', 'CUC', 'Cuban Convertible Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('37', 'CUP', 'Cuban Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('38', 'CVE', 'Cape Verdean Escudo');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('39', 'CZK', 'Czech Republic Koruna');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('40', 'DJF', 'Djiboutian Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('41', 'DKK', 'Danish Krone');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('42', 'DOP', 'Dominican Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('43', 'DZD', 'Algerian Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('44', 'EGP', 'Egyptian Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('45', 'ERN', 'Eritrean Nakfa');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('46', 'ETB', 'Ethiopian Birr');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('47', 'EUR', 'Euro');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('48', 'FJD', 'Fijian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('49', 'FKP', 'Falkland Islands Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('50', 'GBP', 'British Pound Sterling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('51', 'GEL', 'Georgian Lari');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('52', 'GGP', 'Guernsey Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('53', 'GHS', 'Ghanaian Cedi');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('54', 'GIP', 'Gibraltar Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('55', 'GMD', 'Gambian Dalasi');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('56', 'GNF', 'Guinean Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('57', 'GTQ', 'Guatemalan Quetzal');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('58', 'GYD', 'Guyanaese Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('59', 'HKD', 'Hong Kong Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('60', 'HNL', 'Honduran Lempira');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('61', 'HRK', 'Croatian Kuna');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('62', 'HTG', 'Haitian Gourde');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('63', 'HUF', 'Hungarian Forint');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('64', 'IDR', 'Indonesian Rupiah');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('65', 'ILS', 'Israeli New Sheqel');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('66', 'IMP', 'Manx pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('67', 'INR', 'Indian Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('68', 'IQD', 'Iraqi Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('69', 'IRR', 'Iranian Rial');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('70', 'ISK', 'Icelandic Króna');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('71', 'JEP', 'Jersey Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('72', 'JMD', 'Jamaican Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('73', 'JOD', 'Jordanian Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('74', 'JPY', 'Japanese Yen');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('75', 'KES', 'Kenyan Shilling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('76', 'KGS', 'Kyrgystani Som');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('77', 'KHR', 'Cambodian Riel');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('78', 'KMF', 'Comorian Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('79', 'KPW', 'North Korean Won');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('80', 'KRW', 'South Korean Won');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('81', 'KWD', 'Kuwaiti Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('82', 'KYD', 'Cayman Islands Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('83', 'KZT', 'Kazakhstani Tenge');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('84', 'LAK', 'Laotian Kip');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('85', 'LBP', 'Lebanese Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('86', 'LKR', 'Sri Lankan Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('87', 'LRD', 'Liberian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('88', 'LSL', 'Lesotho Loti');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('89', 'LYD', 'Libyan Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('90', 'MAD', 'Moroccan Dirham');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('91', 'MDL', 'Moldovan Leu');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('92', 'MGA', 'Malagasy Ariary');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('93', 'MKD', 'Macedonian Denar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('94', 'MMK', 'Myanma Kyat');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('95', 'MNT', 'Mongolian Tugrik');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('96', 'MOP', 'Macanese Pataca');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('97', 'MRO', 'Mauritanian Ouguiya (pre-2018)');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('98', 'MRU', 'Mauritanian Ouguiya');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('99', 'MUR', 'Mauritian Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('100', 'MVR', 'Maldivian Rufiyaa');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('101', 'MWK', 'Malawian Kwacha');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('102', 'MXN', 'Mexican Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('103', 'MYR', 'Malaysian Ringgit');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('104', 'MZN', 'Mozambican Metical');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('105', 'NAD', 'Namibian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('106', 'NGN', 'Nigerian Naira');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('107', 'NIO', 'Nicaraguan Córdoba');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('108', 'NOK', 'Norwegian Krone');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('109', 'NPR', 'Nepalese Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('110', 'NZD', 'New Zealand Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('111', 'OMR', 'Omani Rial');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('112', 'PAB', 'Panamanian Balboa');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('113', 'PEN', 'Peruvian Nuevo Sol');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('114', 'PGK', 'Papua New Guinean Kina');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('115', 'PHP', 'Philippine Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('116', 'PKR', 'Pakistani Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('117', 'PLN', 'Polish Zloty');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('118', 'PYG', 'Paraguayan Guarani');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('119', 'QAR', 'Qatari Rial');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('120', 'RON', 'Romanian Leu');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('121', 'RSD', 'Serbian Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('122', 'RUB', 'Russian Ruble');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('123', 'RWF', 'Rwandan Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('124', 'SAR', 'Saudi Riyal');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('125', 'SBD', 'Solomon Islands Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('126', 'SCR', 'Seychellois Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('127', 'SDG', 'Sudanese Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('128', 'SEK', 'Swedish Krona');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('129', 'SGD', 'Singapore Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('130', 'SHP', 'Saint Helena Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('131', 'SLL', 'Sierra Leonean Leone');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('132', 'SOS', 'Somali Shilling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('133', 'SRD', 'Surinamese Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('134', 'SSP', 'South Sudanese Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('135', 'STD', 'São Tomé and Príncipe Dobra (pre-2018)');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('136', 'STN', 'São Tomé and Príncipe Dobra');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('137', 'SVC', 'Salvadoran Colón');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('138', 'SYP', 'Syrian Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('139', 'SZL', 'Swazi Lilangeni');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('140', 'THB', 'Thai Baht');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('141', 'TJS', 'Tajikistani Somoni');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('142', 'TMT', 'Turkmenistani Manat');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('143', 'TND', 'Tunisian Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('144', 'TOP', 'Tongan Pa\'anga');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('145', 'TRY', 'Turkish Lira');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('146', 'TTD', 'Trinidad and Tobago Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('147', 'TWD', 'New Taiwan Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('148', 'TZS', 'Tanzanian Shilling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('149', 'UAH', 'Ukrainian Hryvnia');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('150', 'UGX', 'Ugandan Shilling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('151', 'USD', 'United States Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('152', 'UYU', 'Uruguayan Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('153', 'UZS', 'Uzbekistan Som');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('154', 'VEF', 'Venezuelan Bolívar Fuerte');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('155', 'VND', 'Vietnamese Dong');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('156', 'VUV', 'Vanuatu Vatu');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('157', 'WST', 'Samoan Tala');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('158', 'XAF', 'CFA Franc BEAC');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('159', 'XAG', 'Silver Ounce');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('160', 'XAU', 'Gold Ounce');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('161', 'XCD', 'East Caribbean Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('162', 'XDR', 'Special Drawing Rights');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('163', 'XOF', 'CFA Franc BCEAO');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('164', 'XPD', 'Palladium Ounce');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('165', 'XPF', 'CFP Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('166', 'XPT', 'Platinum Ounce');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('167', 'YER', 'Yemeni Rial');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('168', 'ZAR', 'South African Rand');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('169', 'ZMW', 'Zambian Kwacha');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('170', 'ZWL', 'Zimbabwean Dollar');


TRUNCATE current_theme; INSERT INTO current_theme (`id`, `top_offer`, `header`, `carousel`, `banner`, `footer`, `product_section_order`, `cart`, `news`, `detail`, `shop`, `contact`, `login`, `transitions`, `banner_two`); VALUES ('1', '1', '1', '1', '1', '1', '[{\"id\":10,\"name\":\"Second Ad Section\",\"order\":1,\"file_name\":\"sec_ad_banner\",\"status\":1,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Second Ad Section\"},{\"id\":5,\"name\":\"Categories\",\"order\":2,\"file_name\":\"categories\",\"status\":1,\"image\":\"images\\/prototypes\\/categories.jpg\",\"disabled_image\":\"images\\/prototypes\\/categories-cross.jpg\",\"alt\":\"Categories\"},{\"id\":1,\"name\":\"Banner Section\",\"order\":3,\"file_name\":\"banner_section\",\"status\":1,\"image\":\"images\\/prototypes\\/banner_section.jpg\",\"alt\":\"Banner Section\"},{\"id\":9,\"name\":\"Top Selling\",\"order\":4,\"file_name\":\"top\",\"status\":1,\"image\":\"images\\/prototypes\\/top.jpg\",\"disabled_image\":\"images\\/prototypes\\/top-cross.jpg\",\"alt\":\"Top Selling\"},{\"id\":8,\"name\":\"Newest Product Section\",\"order\":5,\"file_name\":\"newest_product\",\"status\":1,\"image\":\"images\\/prototypes\\/newest_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/newest_product-cross.jpg\",\"alt\":\"Newest Product Section\"},{\"id\":11,\"name\":\"Tab Products View\",\"order\":6,\"file_name\":\"tab\",\"status\":1,\"image\":\"images\\/prototypes\\/tab.jpg\",\"disabled_image\":\"images\\/prototypes\\/tab-cross.jpg\",\"alt\":\"Tab Products View\"},{\"id\":3,\"name\":\"Special Products Section\",\"order\":7,\"file_name\":\"special\",\"status\":1,\"image\":\"images\\/prototypes\\/special_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/special_product-cross.jpg\",\"alt\":\"Special Products Section\"},{\"id\":2,\"name\":\"Flash Sale Section\",\"order\":8,\"file_name\":\"flash_sale_section\",\"status\":1,\"image\":\"images\\/prototypes\\/flash_sale_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/flash_sale_section-cross.jpg\",\"alt\":\"Flash Sale Section\"},{\"id\":4,\"name\":\"Ad Section\",\"order\":9,\"file_name\":\"ad_banner_section\",\"status\":1,\"image\":\"images\\/prototypes\\/ad_banner_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/ad_banner_section-cross.jpg\",\"alt\":\"Ad Section\"},{\"id\":6,\"name\":\"Blog Section\",\"order\":10,\"file_name\":\"blog_section\",\"status\":1,\"image\":\"images\\/prototypes\\/blog_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/blog_section-cross.jpg\",\"alt\":\"Blog Section\"},{\"id\":7,\"name\":\"Info Boxes\",\"order\":11,\"file_name\":\"info_boxes\",\"status\":1,\"image\":\"images\\/prototypes\\/info_boxes.jpg\",\"disabled_image\":\"images\\/prototypes\\/info_boxes-cross.jpg\",\"alt\":\"Info Boxes\"}]', '1', '1', '1', '1', '1', '1', '1', '1');


TRUNCATE customers; TRUNCATE customers_basket; TRUNCATE customers_basket_attributes; TRUNCATE customers_info; TRUNCATE devices; TRUNCATE flash_sale; TRUNCATE flate_rate; INSERT INTO flate_rate (`id`, `flate_rate`, `currency`); VALUES ('1', '11', 'USD');


TRUNCATE front_end_theme_content; INSERT INTO front_end_theme_content (`id`, `top_offers`, `headers`, `carousels`, `banners`, `footers`, `product_section_order`, `cart`, `news`, `detail`, `shop`, `contact`, `login`, `transitions`, `banners_two`); VALUES ('1', '', '[
{
\"id\": 1,
\"name\": \"Header One\",
\"image\": \"images/prototypes/header1.jpg\",
\"alt\" : \"header One\" 
},
{
\"id\": 2,
\"name\": \"Header Two\",
\"image\": \"images/prototypes/header2.jpg\",
\"alt\" : \"header Two\" 
},
{
\"id\": 3,
\"name\": \"Header Three\",
\"image\": \"images/prototypes/header3.jpg\",
\"alt\" : \"header Three\" 
},
{
\"id\": 4,
\"name\": \"Header Four\",
\"image\": \"images/prototypes/header4.jpg\",
\"alt\" : \"header Four\" 
},
{
\"id\": 5,
\"name\": \"Header Five\",
\"image\": \"images/prototypes/header5.jpg\",
\"alt\" : \"header Five\" 
},
{
\"id\": 6,
\"name\": \"Header Six\",
\"image\": \"images/prototypes/header6.jpg\",
\"alt\" : \"header Six\" 
},
{
\"id\": 7,
\"name\": \"Header Seven\",
\"image\": \"images/prototypes/header7.jpg\",
\"alt\" : \"header Seven\" 
},
{
\"id\": 8,
\"name\": \"Header Eight\",
\"image\": \"images/prototypes/header8.jpg\",
\"alt\" : \"header Eight\" 
},
{
\"id\": 9,
\"name\": \"Header Nine\",
\"image\": \"images/prototypes/header9.jpg\",
\"alt\" : \"header Nine\" 
},
{
\"id\": 10,
\"name\": \"Header Ten\",
\"image\": \"images/prototypes/header10.jpg\",
\"alt\" : \"header Ten\" 
}
]', '[
{
\"id\": 1,
\"name\": \"Bootstrap Carousel Content Full Screen\",
\"image\": \"images/prototypes/carousal1.jpg\",
\"alt\": \"Bootstrap Carousel Content Full Screen\"
},
{
\"id\": 2,
\"name\": \"Bootstrap Carousel Content Full Width\",
\"image\": \"images/prototypes/carousal2.jpg\",
\"alt\": \"Bootstrap Carousel Content Full Width\"
},
{
\"id\": 3,
\"name\": \"Bootstrap Carousel Content with Left Banner\",
\"image\": \"images/prototypes/carousal3.jpg\",
\"alt\": \"Bootstrap Carousel Content with Left Banner\"
},
{
\"id\": 4,
\"name\": \"Bootstrap Carousel Content with Navigation\",
\"image\": \"images/prototypes/carousal4.jpg\",
\"alt\": \"Bootstrap Carousel Content with Navigation\"
},
{
\"id\": 5,
\"name\": \"Bootstrap Carousel Content with Right Banner\",
\"image\": \"images/prototypes/carousal5.jpg\",
\"alt\": \"Bootstrap Carousel Content with Right Banner\"
}
]', '[
{
\"id\": 1,
\"name\": \"Banner One\",
\"image\": \"images/prototypes/banner1.jpg\",
\"alt\": \"Banner One\"
},
{
\"id\": 2,
\"name\": \"Banner Two\",
\"image\": \"images/prototypes/banner2.jpg\",
\"alt\": \"Banner Two\"
},
{
\"id\": 3,
\"name\": \"Banner Three\",
\"image\": \"images/prototypes/banner3.jpg\",
\"alt\": \"Banner Three\"
},
{
\"id\": 4,
\"name\": \"Banner Four\",
\"image\": \"images/prototypes/banner4.jpg\",
\"alt\": \"Banner Four\"
},
{
\"id\": 5,
\"name\": \"Banner Five\",
\"image\": \"images/prototypes/banner5.jpg\",
\"alt\": \"Banner Five\"
},
{
\"id\": 6,
\"name\": \"Banner Six\",
\"image\": \"images/prototypes/banner6.jpg\",
\"alt\": \"Banner Six\"
},
{
\"id\": 7,
\"name\": \"Banner Seven\",
\"image\": \"images/prototypes/banner7.jpg\",
\"alt\": \"Banner Seven\"
},
{
\"id\": 8,
\"name\": \"Banner Eight\",
\"image\": \"images/prototypes/banner8.jpg\",
\"alt\": \"Banner Eight\"
},
{
\"id\": 9,
\"name\": \"Banner Nine\",
\"image\": \"images/prototypes/banner9.jpg\",
\"alt\": \"Banner Nine\"
},
{
\"id\": 10,
\"name\": \"Banner Ten\",
\"image\": \"images/prototypes/banner10.jpg\",
\"alt\": \"Banner Ten\"
},
{
\"id\": 11,
\"name\": \"Banner Eleven\",
\"image\": \"images/prototypes/banner11.jpg\",
\"alt\": \"Banner Eleven\"
},
{
\"id\": 12,
\"name\": \"Banner Twelve\",
\"image\": \"images/prototypes/banner12.jpg\",
\"alt\": \"Banner Twelve\"
},
{
\"id\": 13,
\"name\": \"Banner Thirteen\",
\"image\": \"images/prototypes/banner13.jpg\",
\"alt\": \"Banner Thirteen\"
},
{
\"id\": 14,
\"name\": \"Banner Fourteen\",
\"image\": \"images/prototypes/banner14.jpg\",
\"alt\": \"Banner Fourteen\"
},
{
\"id\": 15,
\"name\": \"Banner Fifteen\",
\"image\": \"images/prototypes/banner15.jpg\",
\"alt\": \"Banner Fifteen\"
},
{
\"id\": 16,
\"name\": \"Banner Sixteen\",
\"image\": \"images/prototypes/banner16.jpg\",
\"alt\": \"Banner Sixteen\"
},
{
\"id\": 17,
\"name\": \"Banner Seventeen\",
\"image\": \"images/prototypes/banner17.jpg\",
\"alt\": \"Banner Seventeen\"
},
{
\"id\": 18,
\"name\": \"Banner Eighteen\",
\"image\": \"images/prototypes/banner18.jpg\",
\"alt\": \"Banner Eighteen\"
},
{
\"id\": 19,
\"name\": \"Banner Nineteen\",
\"image\": \"images/prototypes/banner19.jpg\",
\"alt\": \"Banner Nineteen\"
}
]', '[
{
\"id\": 1,
\"name\": \"Footer One\",
\"image\": \"images/prototypes/footer1.png\",
\"alt\" : \"Footer One\"
},
{
\"id\": 2,
\"name\": \"Footer Two\",
\"image\": \"images/prototypes/footer2.png\",
\"alt\" : \"Footer Two\"
},
{
\"id\": 3,
\"name\": \"Footer Three\",
\"image\": \"images/prototypes/footer3.png\",
\"alt\" : \"Footer Three\"
},
{
\"id\": 4,
\"name\": \"Footer Four\",
\"image\": \"images/prototypes/footer4.png\",
\"alt\" : \"Footer Four\"
},
{
\"id\": 5,
\"name\": \"Footer Five\",
\"image\": \"images/prototypes/footer5.png\",
\"alt\" : \"Footer Five\"
},
{
\"id\": 6,
\"name\": \"Footer Six\",
\"image\": \"images/prototypes/footer6.png\",
\"alt\" : \"Footer Six\"
},
{
\"id\": 7,
\"name\": \"Footer Seven\",
\"image\": \"images/prototypes/footer7.png\",
\"alt\" : \"Footer Seven\"
},
{
\"id\": 8,
\"name\": \"Footer Eight\",
\"image\": \"images/prototypes/footer8.png\",
\"alt\" : \"Footer Eight\"
},
{
\"id\": 9,
\"name\": \"Footer Nine\",
\"image\": \"images/prototypes/footer9.png\",
\"alt\" : \"Footer Nine\"
},
{
\"id\": 10,
\"name\": \"Footer Ten\",
\"image\": \"images/prototypes/footer10.png\",
\"alt\" : \"Footer Ten\"
}
]', '[{
                    \"id\": 10,
                    \"name\": \"Second Ad Section\",
                    \"order\": 1,
                    \"file_name\": \"sec_ad_banner\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/sec_ad_section.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/sec_ad_section-cross.jpg\",
                    \"alt\": \"Second Ad Section\"
                }, {
                    \"id\": 5,
                    \"name\": \"Categories\",
                    \"order\": 2,
                    \"file_name\": \"categories\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/categories.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/categories-cross.jpg\",
                    \"alt\": \"Categories\"
                }, {
                    \"id\": 1,
                    \"name\": \"Banner Section\",
                    \"order\": 3,
                    \"file_name\": \"banner_section\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/banner_section.jpg\",
                    \"alt\": \"Banner Section\"
                }, {
                    \"id\": 9,
                    \"name\": \"Top Selling\",
                    \"order\": 4,
                    \"file_name\": \"top\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/top.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/top-cross.jpg\",
                    \"alt\": \"Top Selling\"
                }, {
                    \"id\": 8,
                    \"name\": \"Newest Product Section\",
                    \"order\": 5,
                    \"file_name\": \"newest_product\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/newest_product.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/newest_product-cross.jpg\",
                    \"alt\": \"Newest Product Section\"
                }, {
                    \"id\": 11,
                    \"name\": \"Tab Products View\",
                    \"order\": 6,
                    \"file_name\": \"tab\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/tab.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/tab-cross.jpg\",
                    \"alt\": \"Tab Products View\"
                }, {
                    \"id\": 3,
                    \"name\": \"Special Products Section\",
                    \"order\": 7,
                    \"file_name\": \"special\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/special_product.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/special_product-cross.jpg\",
                    \"alt\": \"Special Products Section\"
                }, {
                    \"id\": 2,
                    \"name\": \"Flash Sale Section\",
                    \"order\": 8,
                    \"file_name\": \"flash_sale_section\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/flash_sale_section.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/flash_sale_section-cross.jpg\",
                    \"alt\": \"Flash Sale Section\"
                }, {
                    \"id\": 4,
                    \"name\": \"Ad Section\",
                    \"order\": 9,
                    \"file_name\": \"ad_banner_section\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/ad_banner_section.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/ad_banner_section-cross.jpg\",
                    \"alt\": \"Ad Section\"
                }, {
                    \"id\": 6,
                    \"name\": \"Blog Section\",
                    \"order\": 10,
                    \"file_name\": \"blog_section\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/blog_section.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/blog_section-cross.jpg\",
                    \"alt\": \"Blog Section\"
                }, {
                    \"id\": 12,
                    \"name\": \"Banner 2 Section\",
                    \"order\": 11,
                    \"file_name\": \"banner_two_section\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/sec_ad_section.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/sec_ad_section-cross.jpg\",
                    \"alt\": \"Banner 2 Section\"
                }, {
                    \"id\": 7,
                    \"name\": \"Info Boxes\",
                    \"order\": 12,
                    \"file_name\": \"info_boxes\",
                    \"status\": 1,
                    \"image\": \"images\\/prototypes\\/info_boxes.jpg\",
                    \"disabled_image\": \"images\\/prototypes\\/info_boxes-cross.jpg\",
                    \"alt\": \"Info Boxes\"
                }]
                ', '[      {         \"id\":1,       \"name\":\"Cart One\"    },    {         \"id\":2,       \"name\":\"Cart Two\"    }     ]', '[      {         \"id\":1,       \"name\":\"News One\"    },    {         \"id\":2,       \"name\":\"News Two\"    }     ]', '[  
{  
\"id\":1,
\"name\":\"Product Detail Page One\"
},
{  
\"id\":2,
\"name\":\"Product Detail Page Two\"
},
{  
\"id\":3,
\"name\":\"Product Detail Page Three\"
},
{  
\"id\":4,
\"name\":\"Product Detail Page Four\"
},
{  
\"id\":5,
\"name\":\"Product Detail Page Five\"
},
{  
\"id\":6,
\"name\":\"Product Detail Page Six\"
}

]', '[      {         \"id\":1,       \"name\":\"Shop Page One\"    },    {         \"id\":2,       \"name\":\"Shop Page Two\"    },    {         \"id\":3,       \"name\":\"Shop Page Three\"    },    {         \"id\":4,       \"name\":\"Shop Page Four\"    },    {         \"id\":5,       \"name\":\"Shop Page Five\"    }     ]', '[      {         \"id\":1,       \"name\":\"Contact Page One\"    },    {         \"id\":2,       \"name\":\"Contact Page Two\"    } ]', '[      {         \"id\":1,       \"name\":\"Login Page One\"    },    {         \"id\":2,       \"name\":\"Login Page Two\"    } ]', '[ { \"id\":1, \"name\":\"Transition Zoomin\" }, { \"id\":2, \"name\":\"Transition Flashing\" }, { \"id\":3, \"name\":\"Transition Shine\" }, { \"id\":4, \"name\":\"Transition Circle\" }, { \"id\":5, \"name\":\"Transition Opacity\" } ]', '[ { \"id\": 1, \"name\": \"Banner One\", \"image\": \"images/prototypes/banner1.jpg\", \"alt\": \"Banner One\" }, { \"id\": 2, \"name\": \"Banner Two\", \"image\": \"images/prototypes/banner2.jpg\", \"alt\": \"Banner Two\" }, { \"id\": 3, \"name\": \"Banner Three\", \"image\": \"images/prototypes/banner3.jpg\", \"alt\": \"Banner Three\" }, { \"id\": 4, \"name\": \"Banner Four\", \"image\": \"images/prototypes/banner4.jpg\", \"alt\": \"Banner Four\" }, { \"id\": 5, \"name\": \"Banner Five\", \"image\": \"images/prototypes/banner5.jpg\", \"alt\": \"Banner Five\" }, { \"id\": 6, \"name\": \"Banner Six\", \"image\": \"images/prototypes/banner6.jpg\", \"alt\": \"Banner Six\" }, { \"id\": 7, \"name\": \"Banner Seven\", \"image\": \"images/prototypes/banner7.jpg\", \"alt\": \"Banner Seven\" }, { \"id\": 8, \"name\": \"Banner Eight\", \"image\": \"images/prototypes/banner8.jpg\", \"alt\": \"Banner Eight\" }, { \"id\": 9, \"name\": \"Banner Nine\", \"image\": \"images/prototypes/banner9.jpg\", \"alt\": \"Banner Nine\" }, { \"id\": 10, \"name\": \"Banner Ten\", \"image\": \"images/prototypes/banner10.jpg\", \"alt\": \"Banner Ten\" }, { \"id\": 11, \"name\": \"Banner Eleven\", \"image\": \"images/prototypes/banner11.jpg\", \"alt\": \"Banner Eleven\" }, { \"id\": 12, \"name\": \"Banner Twelve\", \"image\": \"images/prototypes/banner12.jpg\", \"alt\": \"Banner Twelve\" }, { \"id\": 13, \"name\": \"Banner Thirteen\", \"image\": \"images/prototypes/banner13.jpg\", \"alt\": \"Banner Thirteen\" }, { \"id\": 14, \"name\": \"Banner Fourteen\", \"image\": \"images/prototypes/banner14.jpg\", \"alt\": \"Banner Fourteen\" }, { \"id\": 15, \"name\": \"Banner Fifteen\", \"image\": \"images/prototypes/banner15.jpg\", \"alt\": \"Banner Fifteen\" }, { \"id\": 16, \"name\": \"Banner Sixteen\", \"image\": \"images/prototypes/banner16.jpg\", \"alt\": \"Banner Sixteen\" }, { \"id\": 17, \"name\": \"Banner Seventeen\", \"image\": \"images/prototypes/banner17.jpg\", \"alt\": \"Banner Seventeen\" }, { \"id\": 18, \"name\": \"Banner Eighteen\", \"image\": \"images/prototypes/banner18.jpg\", \"alt\": \"Banner Eighteen\" }, { \"id\": 19, \"name\": \"Banner Nineteen\", \"image\": \"images/prototypes/banner19.jpg\", \"alt\": \"Banner Nineteen\" } ]');


TRUNCATE geo_zones; TRUNCATE home_banners; TRUNCATE http_call_record; TRUNCATE image_categories; INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('84', '83', 'ACTUAL', '277', '370', 'images/media/2019/10/JqYfZ11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('85', '83', 'THUMBNAIL', '112', '150', 'images/media/2019/10/thumbnail1570778231JqYfZ11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('86', '84', 'ACTUAL', '301', '770', 'images/media/2019/10/6Q4Qy11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('87', '85', 'ACTUAL', '550', '368', 'images/media/2019/10/jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('88', '85', 'THUMBNAIL', '150', '100', 'images/media/2019/10/thumbnail1570778446jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('89', '85', 'MEDIUM', '400', '268', 'images/media/2019/10/medium1570778446jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('90', '86', 'ACTUAL', '220', '370', 'images/media/2019/10/Ake4A11107.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('91', '86', 'THUMBNAIL', '89', '150', 'images/media/2019/10/thumbnail1570778447Ake4A11107.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('96', '89', 'ACTUAL', '229', '270', 'images/media/2019/10/nDQtA11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('97', '89', 'THUMBNAIL', '127', '150', 'images/media/2019/10/thumbnail1570778680nDQtA11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('98', '90', 'ACTUAL', '298', '568', 'images/media/2019/10/ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('99', '90', 'THUMBNAIL', '79', '150', 'images/media/2019/10/thumbnail1570778749ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('100', '90', 'MEDIUM', '210', '400', 'images/media/2019/10/medium1570778749ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('101', '91', 'ACTUAL', '490', '570', 'images/media/2019/10/xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('102', '91', 'THUMBNAIL', '129', '150', 'images/media/2019/10/thumbnail1570778967xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('103', '91', 'MEDIUM', '344', '400', 'images/media/2019/10/medium1570778967xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('104', '92', 'ACTUAL', '229', '270', 'images/media/2019/10/YZyoU11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('105', '92', 'THUMBNAIL', '127', '150', 'images/media/2019/10/thumbnail1570778968YZyoU11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('106', '93', 'ACTUAL', '301', '770', 'images/media/2019/10/RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('107', '93', 'THUMBNAIL', '59', '150', 'images/media/2019/10/thumbnail1570787475RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('108', '93', 'MEDIUM', '156', '400', 'images/media/2019/10/medium1570787476RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('109', '94', 'ACTUAL', '211', '570', 'images/media/2019/10/pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('110', '94', 'THUMBNAIL', '56', '150', 'images/media/2019/10/thumbnail1570787731pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('111', '94', 'MEDIUM', '148', '400', 'images/media/2019/10/medium1570787731pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('112', '95', 'ACTUAL', '451', '570', 'images/media/2019/10/2t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('113', '95', 'THUMBNAIL', '119', '150', 'images/media/2019/10/thumbnail15707877532t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('114', '95', 'MEDIUM', '316', '400', 'images/media/2019/10/medium15707877542t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('115', '96', 'ACTUAL', '211', '270', 'images/media/2019/10/O0cLp11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('116', '96', 'THUMBNAIL', '117', '150', 'images/media/2019/10/thumbnail1570787792O0cLp11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('117', '97', 'ACTUAL', '298', '568', 'images/media/2019/10/ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('118', '97', 'THUMBNAIL', '79', '150', 'images/media/2019/10/thumbnail1570787936ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('119', '97', 'MEDIUM', '210', '400', 'images/media/2019/10/medium1570787936ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('120', '98', 'ACTUAL', '452', '569', 'images/media/2019/10/3876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('121', '98', 'THUMBNAIL', '119', '150', 'images/media/2019/10/thumbnail15707880203876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('122', '98', 'MEDIUM', '318', '400', 'images/media/2019/10/medium15707880213876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('123', '99', 'ACTUAL', '451', '271', 'images/media/2019/10/80IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('124', '99', 'THUMBNAIL', '150', '90', 'images/media/2019/10/thumbnail157078802180IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('125', '99', 'MEDIUM', '400', '240', 'images/media/2019/10/medium157078802180IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('126', '100', 'ACTUAL', '493', '370', 'images/media/2019/10/ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('127', '100', 'THUMBNAIL', '150', '113', 'images/media/2019/10/thumbnail1570788170ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('128', '100', 'MEDIUM', '400', '300', 'images/media/2019/10/medium1570788171ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('129', '101', 'ACTUAL', '230', '370', 'images/media/2019/10/UrgVW11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('130', '101', 'THUMBNAIL', '93', '150', 'images/media/2019/10/thumbnail1570788171UrgVW11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('131', '102', 'ACTUAL', '230', '370', 'images/media/2019/10/a18kN11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('132', '102', 'THUMBNAIL', '93', '150', 'images/media/2019/10/thumbnail1570788301a18kN11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('133', '103', 'ACTUAL', '493', '370', 'images/media/2019/10/qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('134', '103', 'THUMBNAIL', '150', '113', 'images/media/2019/10/thumbnail1570788302qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('135', '103', 'MEDIUM', '400', '300', 'images/media/2019/10/medium1570788302qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('136', '104', 'ACTUAL', '259', '770', 'images/media/2019/10/VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('137', '104', 'THUMBNAIL', '50', '150', 'images/media/2019/10/thumbnail1570788382VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('138', '104', 'MEDIUM', '135', '400', 'images/media/2019/10/medium1570788382VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('139', '105', 'ACTUAL', '546', '372', 'images/media/2019/10/gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('140', '105', 'THUMBNAIL', '150', '102', 'images/media/2019/10/thumbnail1570788383gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('141', '105', 'MEDIUM', '400', '273', 'images/media/2019/10/medium1570788383gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('142', '106', 'ACTUAL', '430', '1599', 'images/media/2019/10/DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('143', '106', 'THUMBNAIL', '40', '150', 'images/media/2019/10/thumbnail1570789393DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('144', '106', 'MEDIUM', '108', '400', 'images/media/2019/10/medium1570789394DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('145', '106', 'LARGE', '242', '900', 'images/media/2019/10/large1570789394DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('146', '107', 'ACTUAL', '236', '1169', 'images/media/2019/10/N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('147', '107', 'THUMBNAIL', '30', '150', 'images/media/2019/10/thumbnail1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('148', '107', 'MEDIUM', '81', '400', 'images/media/2019/10/medium1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('149', '107', 'LARGE', '182', '900', 'images/media/2019/10/large1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('150', '108', 'ACTUAL', '421', '1170', 'images/media/2019/10/z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('151', '108', 'THUMBNAIL', '54', '150', 'images/media/2019/10/thumbnail1570789643z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('152', '108', 'MEDIUM', '144', '400', 'images/media/2019/10/medium1570789643z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('153', '108', 'LARGE', '324', '900', 'images/media/2019/10/large1570789644z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('154', '109', 'ACTUAL', '418', '885', 'images/media/2019/10/YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('155', '109', 'THUMBNAIL', '71', '150', 'images/media/2019/10/thumbnail1570789935YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('156', '109', 'MEDIUM', '189', '400', 'images/media/2019/10/medium1570789935YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('157', '110', 'ACTUAL', '387', '770', 'images/media/2019/10/YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('158', '110', 'THUMBNAIL', '75', '150', 'images/media/2019/10/thumbnail1570790072YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('159', '110', 'MEDIUM', '201', '400', 'images/media/2019/10/medium1570790072YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('160', '111', 'ACTUAL', '421', '1600', 'images/media/2019/10/97VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('161', '111', 'THUMBNAIL', '39', '150', 'images/media/2019/10/thumbnail157079031897VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('162', '111', 'MEDIUM', '105', '400', 'images/media/2019/10/medium157079031997VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('163', '111', 'LARGE', '237', '900', 'images/media/2019/10/large157079031997VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('168', '114', 'ACTUAL', '179', '370', 'images/media/2019/10/zZZ2n11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('169', '114', 'THUMBNAIL', '73', '150', 'images/media/2019/10/thumbnail1570790472zZZ2n11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('170', '115', 'ACTUAL', '211', '370', 'images/media/2019/10/vMNsa11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('171', '115', 'THUMBNAIL', '86', '150', 'images/media/2019/10/thumbnail1570790553vMNsa11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('172', '116', 'ACTUAL', '208', '465', 'images/media/2019/10/qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('173', '116', 'THUMBNAIL', '67', '150', 'images/media/2019/10/thumbnail1570790554qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('174', '116', 'MEDIUM', '179', '400', 'images/media/2019/10/medium1570790554qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('176', '118', 'ACTUAL', '20', '30', 'images/media/2019/10/PJG0C11511.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('177', '119', 'ACTUAL', '20', '30', 'images/media/2019/10/SKOMJ11512.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('178', '120', 'ACTUAL', '20', '30', 'images/media/2019/10/newsletter.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('179', '121', 'ACTUAL', '1776', '1776', 'images/media/2020/05/KlZKv27811.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('180', '121', 'THUMBNAIL', '150', '150', 'images/media/2020/05/thumbnail1590623612KlZKv27811.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('181', '121', 'MEDIUM', '400', '400', 'images/media/2020/05/medium1590623613KlZKv27811.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('182', '121', 'LARGE', '900', '900', 'images/media/2020/05/large1590623614KlZKv27811.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('183', '122', 'ACTUAL', '315', '456', 'images/media/2020/05/pWvcq27611.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('184', '122', 'THUMBNAIL', '104', '150', 'images/media/2020/05/thumbnail1590623615pWvcq27611.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('185', '122', 'MEDIUM', '276', '400', 'images/media/2020/05/medium1590623615pWvcq27611.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('186', '123', 'ACTUAL', '300', '244', 'images/media/2020/05/4AtPS27111.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('187', '123', 'THUMBNAIL', '150', '122', 'images/media/2020/05/thumbnail15906236154AtPS27111.png', '', '');


TRUNCATE images; INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('3', 'XUF1110211.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('4', '0S9Uj10711.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('5', '49YbL10411.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('83', 'JqYfZ11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('84', '6Q4Qy11507.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('85', 'jOVnc11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('86', 'Ake4A11107.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('89', 'nDQtA11407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('90', 'ueyod11407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('91', 'xD6MF11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('92', 'YZyoU11507.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('93', 'RLshK11309.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('94', 'pTZdI11309.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('95', '2t7BU11909.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('96', 'O0cLp11909.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('97', 'ncXhn11709.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('98', '3876V11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('99', '80IGj11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('100', 'ueeqM11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('101', 'UrgVW11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('102', 'a18kN11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('103', 'qQM0R11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('104', 'VrhhT11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('105', 'gSkR011310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('106', 'DXoxt11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('107', 'N4WSZ11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('108', 'z9MLR11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('109', 'YNVyV11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('110', 'YinE411810.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('111', '97VNC11210.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('114', 'zZZ2n11710.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('115', 'vMNsa11710.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('116', 'qujIz11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('118', 'PJG0C11511.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('119', 'SKOMJ11512.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('120', 'newsletter.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('121', 'KlZKv27811.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('122', 'pWvcq27611.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('123', '4AtPS27111.png', '1', '', '', '');


TRUNCATE inventory; TRUNCATE inventory_detail; TRUNCATE label_value; INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1297', 'Home', '1', '1031');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1298', 'Menu', '1', '1030');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1299', 'Clear', '1', '1029');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1300', 'Apply', '1', '1028');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1301', 'Close', '1', '1027');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1302', 'Price Range', '1', '1026');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1303', 'Filters', '1', '1025');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1304', 'My Wish List', '1', '1024');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1305', 'Log Out', '1', '1023');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1306', 'Please login or create an account for free', '1', '1022');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1307', 'login & Register', '1', '1021');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1308', 'Save Address', '1', '1020');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1309', 'State', '1', '1018');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1310', 'Update Address', '1', '1019');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1311', 'Post code', '1', '1017');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1312', 'City', '1', '1016');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1313', 'Zone', '1', '1015');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1314', 'other', '1', '1014');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1315', 'Country', '1', '1013');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1316', 'Shipping Address', '1', '1012');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1317', 'Proceed', '1', '1011');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1318', 'Remove', '1', '1010');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1319', 'by', '1', '1008');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1320', 'View', '1', '1009');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1321', 'Quantity', '1', '1007');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1322', 'Price', '1', '1006');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1323', 'continue shopping', '1', '1005');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1324', 'Your cart is empty', '1', '1004');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1325', 'My Cart', '1', '1003');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1326', 'Continue', '1', '1002');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1327', 'Error: invalid cvc number!', '1', '1001');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1328', 'Error: invalid expiry date!', '1', '1000');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1329', 'Error: invalid card number!', '1', '999');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1330', 'Expiration', '1', '998');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1331', 'Expiration Date', '1', '997');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1332', 'Card Number', '1', '996');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1333', 'Payment', '1', '995');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1334', 'Order Notes', '1', '994');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1335', 'Shipping Cost', '1', '993');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1336', 'Tax', '1', '992');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1337', 'Products Price', '1', '991');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1338', 'SubTotal', '1', '990');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1339', 'Products', '1', '989');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1340', 'Shipping Method', '1', '988');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1341', 'Billing Address', '1', '987');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1342', 'Order', '1', '986');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1343', 'Next', '1', '985');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1344', 'Same as Shipping Address', '1', '984');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1345', 'Billing Info', '1', '981');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1346', 'Address', '1', '982');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1347', 'Phone', '1', '983');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1348', 'Already Memeber?', '1', '980');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1349', 'Last Name', '1', '979');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1350', 'First Name', '1', '978');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1351', 'Create an Account', '1', '977');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1352', 'Add new Address', '1', '976');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1353', 'Please add your new shipping address for the futher processing of the your order', '1', '975');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1354', 'Order Status', '1', '969');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1355', 'Orders ID', '1', '970');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1356', 'Product Price', '1', '971');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1357', 'No. of Products', '1', '972');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1358', 'Date', '1', '973');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1359', 'Customer Address', '1', '974');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1360', 'Customer Orders', '1', '968');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1361', 'Change Password', '1', '967');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1362', 'New Password', '1', '966');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1363', 'Current Password', '1', '965');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1364', 'Update', '1', '964');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1365', 'Date of Birth', '1', '963');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1366', 'Mobile', '1', '962');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1367', 'My Account', '1', '961');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1368', 'Likes', '1', '960');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1369', 'Newest', '1', '959');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1370', 'Top Seller', '1', '958');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1371', 'Special', '1', '957');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1372', 'Most Liked', '1', '956');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1373', 'Cancel', '1', '955');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1374', 'Sort Products', '1', '954');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1375', 'Special Products', '1', '953');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1376', 'Price : low - high', '1', '952');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1377', 'Price : high - low', '1', '951');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1378', 'Z - A', '1', '950');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1379', 'A - Z', '1', '949');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1380', 'All', '1', '948');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1381', 'Explore More', '1', '947');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1382', 'Note to the buyer', '1', '946');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1383', 'Coupon', '1', '945');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1384', 'coupon code', '1', '944');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1385', 'Coupon Amount', '1', '943');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1386', 'Coupon Code', '1', '942');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1387', 'Food Categories', '1', '941');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1388', 'Recipe of Day', '1', '940');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1389', 'Top Dishes', '1', '939');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1390', 'Skip', '1', '938');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1391', 'Term and Services', '1', '937');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1392', 'Privacy Policy', '1', '936');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1393', 'Refund Policy', '1', '935');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1394', 'Newest', '1', '934');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1395', 'OUT OF STOCK', '1', '933');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1396', 'Select Language', '1', '932');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1397', 'Reset', '1', '931');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1398', 'Shop', '1', '930');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1399', 'Settings', '1', '929');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1400', 'Enter keyword', '1', '928');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1401', 'News', '1', '927');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1402', 'Top Sellers', '1', '926');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1403', 'Go Back', '1', '925');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1404', 'Word Press Post Detail', '1', '924');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1405', 'Explore', '1', '923');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1406', 'Continue Adding', '1', '922');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1407', 'Your wish List is empty', '1', '921');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1408', 'Favourite', '1', '920');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1409', 'Continue Shopping', '1', '919');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1410', 'My Orders', '1', '918');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1411', 'Thank you for shopping with us.', '1', '917');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1412', 'Thank You', '1', '916');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1413', 'Shipping method', '1', '915');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1414', 'Sub Categories', '1', '914');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1415', 'Main Categories', '1', '913');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1416', 'Search', '1', '912');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1417', 'Reset Filters', '1', '911');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1418', 'No Products Found', '1', '910');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1419', 'OFF', '1', '909');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1420', 'Techincal details', '1', '908');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1421', 'Product Description', '1', '907');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1422', 'ADD TO CART', '1', '906');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1423', 'Add to Cart', '1', '905');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1424', 'In Stock', '1', '904');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1425', 'Out of Stock', '1', '903');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1426', 'New', '1', '902');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1427', 'Product Details', '1', '901');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1428', 'Shipping', '1', '900');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1429', 'Sub Total', '1', '899');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1430', 'Total', '1', '898');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1431', 'Price Detail', '1', '897');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1432', 'Order Detail', '1', '896');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1433', 'Got It!', '1', '895');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1434', 'Skip Intro', '1', '894');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1435', 'Intro', '1', '893');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1436', 'REMOVE', '1', '892');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1437', 'Deals', '1', '891');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1438', 'All Categories', '1', '890');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1439', 'Most Liked', '1', '889');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1440', 'Special Deals', '1', '888');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1441', 'Top Seller', '1', '887');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1442', 'Products are available.', '1', '886');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1443', 'Recently Viewed', '1', '885');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1444', 'Please connect to the internet', '1', '884');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1445', 'Contact Us', '1', '881');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1446', 'Name', '1', '882');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1447', 'Your Message', '1', '883');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1448', 'Categories', '1', '880');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1449', 'About Us', '1', '879');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1450', 'Send', '1', '878');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1451', 'Forgot Password', '1', '877');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1452', 'Register', '1', '876');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1453', 'Password', '1', '875');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1454', 'Email', '1', '874');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1455', 'or', '1', '873');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1456', 'Login with', '1', '872');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1457', 'Creating an account means you\'re okay with shopify\'s Terms of Service, Privacy Policy', '1', '2');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1458', 'I\'ve forgotten my password?', '1', '1');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1459', '', '1', '');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1462', 'Creating an account means you’re okay with our', '1', '1033');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1465', 'Login', '1', '1034');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1468', 'Turn on/off Local Notifications', '1', '1035');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1471', 'Turn on/off Notifications', '1', '1036');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1474', 'Change Language', '1', '1037');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1477', 'Official Website', '1', '1038');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1480', 'Rate Us', '1', '1039');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1483', 'Share', '1', '1040');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1486', 'Edit Profile', '1', '1041');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1489', 'A percentage discount for the entire cart', '1', '1042');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1492', 'A fixed total discount for the entire cart', '1', '1043');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1495', 'A fixed total discount for selected products only', '1', '1044');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1498', 'A percentage discount for selected products only', '1', '1045');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1501', 'Network Connected Reloading Data', '1', '1047');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1503', 'Sort by', '1', '1048');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1505', 'Flash Sale', '1', '1049');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1507', 'ok', '1', '1050');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1509', 'Number', '1', '1051');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1511', 'Expire Month', '1', '1052');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1513', 'Expire Year', '1', '1053');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1515', 'Payment Method', '1', '1054');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1517', 'Status', '1', '1055');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1519', 'And', '1', '1056');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1520', '', '2', '');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1521', '', '1', '1072');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1522', '', '2', '1072');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1523', '', '1', '1073');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1524', '', '2', '1073');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1525', '', '1', '1074');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1526', '', '2', '1074');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1527', '', '1', '1075');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1528', '', '2', '1075');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1529', '', '1', '1076');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1530', '', '2', '1076');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1531', '', '1', '1077');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1532', '', '2', '1077');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1533', '', '1', '1078');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1534', '', '2', '1078');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1535', '', '1', '1079');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1536', '', '2', '1079');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1537', '', '1', '1080');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1538', '', '2', '1080');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1539', '', '1', '1081');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1540', '', '2', '1081');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1541', '', '1', '1082');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1542', '', '2', '1082');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1543', '', '1', '1083');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1544', '', '2', '1083');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1545', '', '1', '1084');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1546', '', '2', '1084');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1547', '', '1', '1085');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1548', '', '2', '1085');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1549', '', '1', '1086');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1550', '', '2', '1086');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1551', '', '1', '1087');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1552', '', '2', '1087');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1553', '', '1', '1088');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1554', '', '2', '1088');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1555', '', '1', '1089');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1556', '', '2', '1089');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1557', '', '1', '1090');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1558', '', '2', '1090');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1559', '', '1', '1091');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1560', '', '2', '1091');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1561', '', '1', '1092');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1562', '', '2', '1092');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1563', '', '1', '1093');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1564', '', '2', '1093');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1565', '', '1', '1094');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1566', '', '2', '1094');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1567', '', '1', '1095');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1568', '', '2', '1095');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1569', '', '1', '1096');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1570', '', '2', '1096');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1571', '', '1', '1097');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1572', '', '2', '1097');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1573', 'Account', '1', '1098');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1574', '', '2', '1098');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1575', '', '2', '1020');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1576', '', '2', '1021');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1577', '', '2', '1022');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1578', '', '2', '1023');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1579', '', '2', '1024');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1580', '', '2', '1025');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1581', '', '2', '1026');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1582', '', '2', '1027');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1583', '', '2', '1028');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1584', '', '2', '1029');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1585', '', '2', '1030');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1586', '', '2', '1031');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1587', '', '2', '1033');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1588', '', '2', '1034');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1589', '', '2', '1035');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1590', '', '2', '1036');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1591', '', '2', '1037');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1592', '', '2', '1038');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1593', '', '2', '1039');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1594', '', '2', '1040');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1595', '', '2', '1041');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1596', '', '2', '1042');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1597', '', '2', '1043');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1598', '', '2', '1044');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1599', '', '2', '1045');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1600', '', '2', '1047');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1601', '', '2', '1048');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1602', '', '2', '1049');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1603', '', '2', '1050');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1604', '', '2', '1051');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1605', '', '2', '1052');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1606', '', '2', '1053');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1607', '', '2', '1054');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1608', '', '2', '1055');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1609', '', '2', '1056');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1610', '', '1', '1057');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1611', '', '2', '1057');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1612', 'All Products', '1', '1058');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1613', '', '2', '1058');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1614', 'Coupon Codes List', '1', '1059');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1615', '', '2', '1059');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1616', 'Custom Orders', '1', '1060');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1617', '', '2', '1060');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1618', 'DETAILS', '1', '1061');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1619', '', '2', '1061');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1620', 'Deals Products', '1', '1062');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1621', '', '2', '1062');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1622', 'Discount ends in', '1', '1063');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1623', '', '2', '1063');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1624', 'Featured Products', '1', '1064');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1625', '', '2', '1064');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1626', 'Most Liked Products', '1', '1065');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1627', '', '2', '1065');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1628', 'Newest Products', '1', '1066');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1629', '', '2', '1066');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1630', 'On Sale Products', '1', '1067');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1631', '', '2', '1067');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1632', 'Posts', '1', '1068');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1633', '', '2', '1068');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1634', 'Safe Payment', '1', '1069');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1635', '', '2', '1069');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1636', 'Secure Online Paymen', '1', '1070');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1637', '', '2', '1070');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1638', 'Select Currency', '1', '1071');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1639', '', '2', '1071');


TRUNCATE labels; INSERT INTO labels (`label_id`, `label_name`); VALUES ('1', 'I\'ve forgotten my password?');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('2', 'Creating an account means you’re okay with shopify\'s Terms of Service, Privacy Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('872', 'Login with');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('873', 'or');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('874', 'Email');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('875', 'Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('876', 'Register');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('877', 'Forgot Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('878', 'Send');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('879', 'About Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('880', 'Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('881', 'Contact Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('882', 'Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('883', 'Your Messsage');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('884', 'Please connect to the internet');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('885', 'Recently Viewed');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('886', 'Products are available.');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('887', 'Top Seller');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('888', 'Special Deals');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('889', 'Most Liked');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('890', 'All Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('891', 'Deals');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('892', 'REMOVE');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('893', 'Intro');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('894', 'Skip Intro');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('895', 'Got It!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('896', 'Order Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('897', 'Price Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('898', 'Total');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('899', 'Sub Total');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('900', 'Shipping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('901', 'Product Details');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('902', 'New');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('903', 'Out of Stock');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('904', 'In Stock');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('905', 'Add to Cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('906', 'ADD TO CART');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('907', 'Product Description');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('908', 'Techincal details');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('909', 'OFF');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('910', 'No Products Found');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('911', 'Reset Filters');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('912', 'Search');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('913', 'Main Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('914', 'Sub Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('915', 'Shipping method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('916', 'Thank You');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('917', 'Thank you for shopping with us.');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('918', 'My Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('919', 'Continue Shopping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('920', 'Favourite');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('921', 'Your wish List is empty');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('922', 'Continue Adding');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('923', 'Explore');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('924', 'Word Press Post Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('925', 'Go Back');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('926', 'Top Sellers');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('927', 'News');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('928', 'Enter keyword');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('929', 'Settings');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('930', 'Shop');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('931', 'Reset');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('932', 'Select Language');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('933', 'OUT OF STOCK');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('934', 'Newest');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('935', 'Refund Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('936', 'Privacy Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('937', 'Term and Services');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('938', 'Skip');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('939', 'Top Dishes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('940', 'Recipe of Day');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('941', 'Food Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('942', 'Coupon Code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('943', 'Coupon Amount');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('944', 'coupon code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('945', 'Coupon');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('946', 'Note to the buyer');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('947', 'Explore More');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('948', 'All');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('949', 'A - Z');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('950', 'Z - A');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('951', 'Price : high - low');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('952', 'Price : low - high');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('953', 'Special Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('954', 'Sort Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('955', 'Cancel');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('956', 'most liked');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('957', 'special');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('958', 'top seller');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('959', 'newest');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('960', 'Likes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('961', 'My Account');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('962', 'Mobile');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('963', 'Date of Birth');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('964', 'Update');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('965', 'Current Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('966', 'New Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('967', 'Change Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('968', 'Customer Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('969', 'Order Status');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('970', 'Orders ID');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('971', 'Product Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('972', 'No. of Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('973', 'Date');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('974', 'Customer Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('975', 'Please add your new shipping address for the futher processing of the your order');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('976', 'Add new Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('977', 'Create an Account');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('978', 'First Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('979', 'Last Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('980', 'Already Memeber?');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('981', 'Billing Info');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('982', 'Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('983', 'Phone');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('984', 'Same as Shipping Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('985', 'Next');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('986', 'Order');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('987', 'Billing Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('988', 'Shipping Method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('989', 'Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('990', 'SubTotal');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('991', 'Products Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('992', 'Tax');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('993', 'Shipping Cost');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('994', 'Order Notes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('995', 'Payment');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('996', 'Card Number');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('997', 'Expiration Date');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('998', 'Expiration');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('999', 'Error: invalid card number!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1000', 'Error: invalid expiry date!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1001', 'Error: invalid cvc number!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1002', 'Continue');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1003', 'My Cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1004', 'Your cart is empty');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1005', 'continue shopping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1006', 'Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1007', 'Quantity');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1008', 'by');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1009', 'View');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1010', 'Remove');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1011', 'Proceed');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1012', 'Shipping Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1013', 'Country');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1014', 'other');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1015', 'Zone');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1016', 'City');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1017', 'Post code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1018', 'State');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1019', 'Update Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1020', 'Save Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1021', 'Login & Register');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1022', 'Please login or create an account for free');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1023', 'Log Out');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1024', 'My Wish List');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1025', 'Filters');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1026', 'Price Range');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1027', 'Close');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1028', 'Apply');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1029', 'Clear');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1030', 'Menu');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1031', 'Home');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1033', 'Creating an account means you’re okay with our');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1034', 'Login');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1035', 'Turn on/off Local Notifications');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1036', 'Turn on/off Notifications');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1037', 'Change Language');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1038', 'Official Website');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1039', 'Rate Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1040', 'Share');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1041', 'Edit Profile');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1042', 'A percentage discount for the entire cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1043', 'A fixed total discount for the entire cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1044', 'A fixed total discount for selected products only');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1045', 'A percentage discount for selected products only');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1047', 'Network Connected Reloading Data');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1048', 'Sort by');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1049', 'Flash Sale');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1050', 'ok');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1051', 'Number');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1052', 'Expire Month');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1053', 'Expire Year');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1054', 'Payment Method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1055', 'Status');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1056', 'And');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1057', 'cccc');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1058', 'All Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1059', 'Coupon Codes List');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1060', 'Custom Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1061', 'DETAILS');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1062', 'Deals Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1063', 'Discount ends in');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1064', 'Featured Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1065', 'Most Liked Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1066', 'Newest Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1067', 'On Sale Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1068', 'Posts');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1069', 'Safe Payment');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1070', 'Secure Online Paymen');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1071', 'Select Currency');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1072', 'Terms and Services');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1073', 'Top Seller Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1074', 'Wish List');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1075', 'Product Quantity is Limited!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1076', 'Error server not reponding');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1077', 'Please Enter Your New Password!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1078', 'Please Enter Your Current Password!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1079', 'Current Password is Wrong!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1080', 'Product Not Available With these Attributes!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1081', 'Please enter something');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1082', 'Disconnected');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1083', 'Connected');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1084', 'Error logging into Facebook');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1085', 'Error Check Login Status Facebook');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1086', 'Please enter coupon code!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1087', 'Error or render dialog closed without being successful');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1088', 'Error in configuration');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1089', 'Error in initialization, maybe PayPal isnt supported or something else');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1090', 'Sorry Coupon is Expired');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1091', 'Sorry your Cart total is low than coupon min limit!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1092', 'Sorry your Cart total is Higher than coupon Max limit!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1093', 'Sorry, this coupon is not valid for this email address!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1094', 'Sorry, this coupon is not valid for sale items.');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1095', 'Coupon code already applied!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1096', 'Sorry Individual Use Coupon is already applied any other coupon cannot be applied with it !');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1097', 'Coupon usage limit has been reached.');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1098', 'Account');


TRUNCATE languages; INSERT INTO languages (`languages_id`, `name`, `code`, `image`, `directory`, `sort_order`, `direction`, `status`, `is_default`); VALUES ('1', 'English', 'en', '118', '', '1', 'ltr', '1', '0');


INSERT INTO languages (`languages_id`, `name`, `code`, `image`, `directory`, `sort_order`, `direction`, `status`, `is_default`); VALUES ('2', 'Arabic', 'ar', '119', '', '2', 'rtl', '0', '1');


TRUNCATE liked_products; TRUNCATE manage_min_max; TRUNCATE manage_role; INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`); VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');


TRUNCATE manufacturers; TRUNCATE manufacturers_info; TRUNCATE menu_translation; INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('2', '1', '1', 'Home');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('3', '1', '2', 'Homee');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('11', '2', '1', 'SHOP');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('12', '2', '2', 'SHOP');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('25', '3', '1', 'INFO PAGES');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('26', '3', '2', 'INFO PAGES');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('33', '18', '1', 'About Us');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('34', '18', '2', 'About Us');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('35', '19', '1', 'Privacy Policy');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('36', '19', '2', 'Privacy Policy');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('37', '20', '1', 'News');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('38', '20', '2', 'News');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('39', '21', '1', 'Demo');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('40', '21', '2', 'Demo');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('41', '22', '1', 'Contact Us');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('42', '22', '2', 'Contact Us');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('45', '24', '1', 'Sub Menu 1');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('46', '24', '2', 'Sub Menu 1');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('47', '25', '1', 'Sub Menu 12');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('48', '25', '2', 'Sub Menu 12');


TRUNCATE menus; INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('1', '1', '', '0', '1', '', '/', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('2', '2', '', '0', '1', '', 'shop', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('3', '4', '', '0', '1', '', '#', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('18', '', '4', '3', '1', '', '/page?name=about-us', '1', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('19', '', '2', '3', '1', '', '/page?name=privacy-policy', '1', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('20', '5', '', '0', '1', '', '#', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('22', '6', '', '0', '1', '', 'contact', '1', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('24', '', '3', '3', '1', '', 'page?name=about-us', '1', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('25', '', '1', '3', '1', '', 'page?name=privacy-policy', '1', '1', '', '');


TRUNCATE migrations; INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('1', '2019_09_24_122557_create_address_book_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('2', '2019_09_24_122557_create_alert_settings_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('3', '2019_09_24_122557_create_api_calls_list_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('4', '2019_09_24_122557_create_banners_history_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('5', '2019_09_24_122557_create_banners_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('6', '2019_09_24_122557_create_block_ips_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('7', '2019_09_24_122557_create_categories_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('8', '2019_09_24_122557_create_categories_role_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('9', '2019_09_24_122557_create_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('10', '2019_09_24_122557_create_compare_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('11', '2019_09_24_122557_create_constant_banners_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('12', '2019_09_24_122557_create_countries_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('13', '2019_09_24_122557_create_coupons_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('14', '2019_09_24_122557_create_currencies_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('15', '2019_09_24_122557_create_currency_record_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('16', '2019_09_24_122557_create_current_theme_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('17', '2019_09_24_122557_create_customers_basket_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('18', '2019_09_24_122557_create_customers_basket_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('19', '2019_09_24_122557_create_customers_info_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('20', '2019_09_24_122557_create_customers_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('21', '2019_09_24_122557_create_devices_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('22', '2019_09_24_122557_create_flash_sale_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('23', '2019_09_24_122557_create_flate_rate_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('24', '2019_09_24_122557_create_front_end_theme_content_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('25', '2019_09_24_122557_create_geo_zones_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('26', '2019_09_24_122557_create_http_call_record_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('27', '2019_09_24_122557_create_image_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('28', '2019_09_24_122557_create_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('29', '2019_09_24_122557_create_inventory_detail_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('30', '2019_09_24_122557_create_inventory_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('31', '2019_09_24_122557_create_label_value_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('32', '2019_09_24_122557_create_labels_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('33', '2019_09_24_122557_create_languages_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('34', '2019_09_24_122557_create_liked_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('35', '2019_09_24_122557_create_manage_min_max_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('36', '2019_09_24_122557_create_manage_role_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('37', '2019_09_24_122557_create_manufacturers_info_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('38', '2019_09_24_122557_create_manufacturers_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('39', '2019_09_24_122557_create_news_categories_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('40', '2019_09_24_122557_create_news_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('41', '2019_09_24_122557_create_news_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('42', '2019_09_24_122557_create_news_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('43', '2019_09_24_122557_create_news_to_news_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('44', '2019_09_24_122557_create_orders_products_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('45', '2019_09_24_122557_create_orders_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('46', '2019_09_24_122557_create_orders_status_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('47', '2019_09_24_122557_create_orders_status_history_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('48', '2019_09_24_122557_create_orders_status_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('49', '2019_09_24_122557_create_orders_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('50', '2019_09_24_122557_create_orders_total_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('51', '2019_09_24_122557_create_pages_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('52', '2019_09_24_122557_create_pages_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('53', '2019_09_24_122557_create_payment_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('54', '2019_09_24_122557_create_payment_methods_detail_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('55', '2019_09_24_122557_create_payment_methods_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('56', '2019_09_24_122557_create_permissions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('57', '2019_09_24_122557_create_products_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('58', '2019_09_24_122557_create_products_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('59', '2019_09_24_122557_create_products_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('60', '2019_09_24_122557_create_products_options_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('61', '2019_09_24_122557_create_products_options_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('62', '2019_09_24_122557_create_products_options_values_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('63', '2019_09_24_122557_create_products_options_values_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('64', '2019_09_24_122557_create_products_shipping_rates_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('65', '2019_09_24_122557_create_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('66', '2019_09_24_122557_create_products_to_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('67', '2019_09_24_122557_create_reviews_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('68', '2019_09_24_122557_create_reviews_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('69', '2019_09_24_122557_create_sessions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('70', '2019_09_24_122557_create_settings_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('71', '2019_09_24_122557_create_shipping_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('72', '2019_09_24_122557_create_shipping_methods_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('73', '2019_09_24_122557_create_sliders_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('74', '2019_09_24_122557_create_specials_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('75', '2019_09_24_122557_create_tax_class_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('76', '2019_09_24_122557_create_tax_rates_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('77', '2019_09_24_122557_create_units_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('78', '2019_09_24_122557_create_units_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('79', '2019_09_24_122557_create_ups_shipping_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('80', '2019_09_24_122557_create_user_to_address_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('81', '2019_09_24_122557_create_user_types_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('82', '2019_09_24_122557_create_users_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('83', '2019_09_24_122557_create_whos_online_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('84', '2019_09_24_122557_create_zones_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('85', '2019_09_24_122557_create_zones_to_geo_zones_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('86', '2019_12_11_070737_create_menus_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('87', '2019_12_11_070821_create_menu_translation_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('88', '2020_02_04_121358_top_offers', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('89', '2020_03_25_141022_create_home_banners', '1');


TRUNCATE news; TRUNCATE news_categories; TRUNCATE news_categories_description; TRUNCATE news_description; TRUNCATE news_to_news_categories; TRUNCATE orders; TRUNCATE orders_products; TRUNCATE orders_products_attributes; TRUNCATE orders_status; INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('1', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('2', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('3', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('4', '0', '0', '2');


TRUNCATE orders_status_description; INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('1', '1', 'Pending', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('2', '2', 'Completed', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('3', '3', 'Cancel', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('4', '4', 'Return', '1');


TRUNCATE orders_status_history; TRUNCATE orders_total; TRUNCATE pages; INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('1', 'privacy-policy', '1', '1');


INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('2', 'term-services', '1', '1');


INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('3', 'refund-policy', '1', '1');


INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('4', 'about-us', '1', '1');


INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('5', 'privacy-policy', '1', '2');


INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('6', 'term-services', '1', '2');


INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('7', 'refund-policy', '1', '2');


INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('8', 'about-us', '1', '2');


INSERT INTO pages (`page_id`, `slug`, `status`, `type`); VALUES ('9', 'cookies', '1', '2');


TRUNCATE pages_description; INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('1', 'Privacy Policy', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy</p>

<p>text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen</p>

<p>book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially</p>

<p>unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,</p>

<p>and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem</p>

<p>Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard</p>

<p>dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type</p>

<p>specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining</p>

<p>essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum</p>

<p>passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem</p>

<p>Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s</p>

<p>standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make</p>

<p>a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum.</p>
', '1', '1');


INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('4', 'Term & Services', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy</p>

<p>text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen</p>

<p>book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially</p>

<p>unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,</p>

<p>and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem</p>

<p>Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard</p>

<p>dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type</p>

<p>specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining</p>

<p>essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum</p>

<p>passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem</p>

<p>Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s</p>

<p>standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make</p>

<p>a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum.</p>
', '1', '2');


INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('7', 'Refund Policy', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy</p>

<p>text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen</p>

<p>book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially</p>

<p>unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,</p>

<p>and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem</p>

<p>Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard</p>

<p>dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type</p>

<p>specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining</p>

<p>essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum</p>

<p>passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem</p>

<p>Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s</p>

<p>standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make</p>

<p>a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum.</p>
', '1', '3');


INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('10', 'About Us', '<h2><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong></h2>

<p>Cras non justo sed nulla finibus pulvinar sit amet et neque. Duis et odio vitae orci mattis gravida. Nullam vel tincidunt ex. Praesent vel neque egestas arcu feugiat venenatis. Donec eget dolor quis justo tempus mattis. Phasellus dictum nunc ut dapibus dictum. Etiam vel leo nulla. Ut eu mi hendrerit, eleifend lacus sed, dictum neque.</p>

<p>Aliquam non convallis nibh. Donec luctus purus magna, et commodo urna fermentum sed. Cras vel ex blandit, pretium nulla id, efficitur massa. Suspendisse potenti. Maecenas vel vehicula velit. Etiam quis orci molestie, elementum nisl eget, ultricies felis. Ut condimentum quam ut mi scelerisque accumsan. Suspendisse potenti. Etiam orci purus, iaculis sit amet ornare sit amet, finibus sed ligula. Quisque et mollis libero, sit amet consectetur augue. Vestibulum posuere pellentesque enim, in facilisis diam dictum eget. Phasellus sed vestibulum urna, in aliquet felis. Vivamus quis lacus id est ornare faucibus at id nulla.</p>

<h2>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</h2>

<p>Nulla justo lectus, sollicitudin at lorem eu, sollicitudin molestie augue. Maecenas egestas facilisis dolor mattis feugiat. Donec sed orci tellus. Maecenas tortor ipsum, varius vel dolor nec, bibendum porttitor felis. Mauris rutrum tristique vehicula. Sed ullamcorper nisl non erat pharetra, sit amet mattis enim posuere. Nulla convallis fringilla tortor, at vestibulum mauris cursus eget. Ut semper sollicitudin odio, sed molestie libero luctus quis. Integer viverra rutrum diam non maximus. Maecenas pellentesque tortor et sapien fermentum laoreet non et est. Phasellus felis quam, laoreet rhoncus erat eget, tempor condimentum massa. Integer gravida turpis id suscipit bibendum. Phasellus pellentesque venenatis erat, ut maximus justo vulputate sed. Vestibulum maximus enim ligula, non suscipit lectus dignissim vel. Suspendisse eleifend lorem egestas, tristique ligula id, condimentum est.</p>

<p>Mauris nulla nulla, laoreet at auctor quis, bibendum rutrum neque. Donec eu ligula mi. Nam cursus vulputate semper. Phasellus facilisis mollis tellus, interdum laoreet justo rutrum pulvinar. Praesent molestie, nibh sed ultrices porttitor, nulla tortor volutpat enim, quis auctor est sem et orci. Proin lacinia vestibulum ex ut convallis. Phasellus tempus odio purus.</p>

<ul>
<li>Nam lacinia urna eu arcu auctor, eget euismod metus sagittis.</li>
<li>Etiam eleifend ex eu interdum varius.</li>
<li>Nunc dapibus purus eu felis tincidunt, vel rhoncus erat tristique.</li>
<li>Aenean nec augue sit amet lorem blandit ultrices.</li>
<li>Nullam at lacus eleifend, pulvinar velit tempor, auctor nisi.</li>
</ul>

<p>Nunc accumsan tincidunt augue sed blandit. Duis et dignissim nisi. Phasellus sed ligula velit. Etiam rhoncus aliquet magna, nec volutpat nulla imperdiet et. Nunc vel tincidunt magna. Vestibulum lacinia odio a metus placerat maximus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam et faucibus neque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean et metus malesuada, ullamcorper dui vel, convallis est. Donec congue libero sed turpis porta consequat. Suspendisse potenti. Aliquam pharetra nibh in magna iaculis, non elementum ipsum luctus.</p>

<p>&nbsp;</p>', '1', '4');


INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('13', 'Privacy Policy', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy</p>

<p>text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen</p>

<p>book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially</p>

<p>unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,</p>

<p>and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem</p>

<p>Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard</p>

<p>dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type</p>

<p>specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining</p>

<p>essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum</p>

<p>passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem</p>

<p>Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s</p>

<p>standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make</p>

<p>a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum.</p>', '1', '5');


INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('16', 'Term & Services', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy</p>

<p>text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen</p>

<p>book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially</p>

<p>unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,</p>

<p>and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem</p>

<p>Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard</p>

<p>dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type</p>

<p>specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining</p>

<p>essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum</p>

<p>passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem</p>

<p>Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s</p>

<p>standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make</p>

<p>a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum.</p>', '1', '6');


INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('19', 'Refund Policy', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy</p>

<p>text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen</p>

<p>book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially</p>

<p>unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,</p>

<p>and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Lorem</p>

<p>Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard</p>

<p>dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type</p>

<p>specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining</p>

<p>essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum</p>

<p>passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem</p>

<p>Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s</p>

<p>standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make</p>

<p>a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>

<p>the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>

<p>it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>

<p>remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing</p>

<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions</p>

<p>of Lorem Ipsum.</p>', '1', '7');


INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('22', 'About Us', '<h2><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong></h2>

<p><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong></p>

<p>Cras non justo sed nulla finibus pulvinar sit amet et neque. Duis et odio vitae orci mattis gravida. Nullam vel tincidunt ex. Praesent vel neque egestas arcu feugiat venenatis. Donec eget dolor quis justo tempus mattis. Phasellus dictum nunc ut dapibus dictum. Etiam vel leo nulla. Ut eu mi hendrerit, eleifend lacus sed, dictum neque.</p>

<p>Aliquam non convallis nibh. Donec luctus purus magna, et commodo urna fermentum sed. Cras vel ex blandit, pretium nulla id, efficitur massa. Suspendisse potenti. Maecenas vel vehicula velit. Etiam quis orci molestie, elementum nisl eget, ultricies felis. Ut condimentum quam ut mi scelerisque accumsan. Suspendisse potenti. Etiam orci purus, iaculis sit amet ornare sit amet, finibus sed ligula. Quisque et mollis libero, sit amet consectetur augue. Vestibulum posuere pellentesque enim, in facilisis diam dictum eget. Phasellus sed vestibulum urna, in aliquet felis. Vivamus quis lacus id est ornare faucibus at id nulla.</p>

<h2>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</h2>

<p>Nulla justo lectus, sollicitudin at lorem eu, sollicitudin molestie augue. Maecenas egestas facilisis dolor mattis feugiat. Donec sed orci tellus. Maecenas tortor ipsum, varius vel dolor nec, bibendum porttitor felis. Mauris rutrum tristique vehicula. Sed ullamcorper nisl non erat pharetra, sit amet mattis enim posuere. Nulla convallis fringilla tortor, at vestibulum mauris cursus eget. Ut semper sollicitudin odio, sed molestie libero luctus quis. Integer viverra rutrum diam non maximus. Maecenas pellentesque tortor et sapien fermentum laoreet non et est. Phasellus felis quam, laoreet rhoncus erat eget, tempor condimentum massa. Integer gravida turpis id suscipit bibendum. Phasellus pellentesque venenatis erat, ut maximus justo vulputate sed. Vestibulum maximus enim ligula, non suscipit lectus dignissim vel. Suspendisse eleifend lorem egestas, tristique ligula id, condimentum est.</p>

<p>Mauris nulla nulla, laoreet at auctor quis, bibendum rutrum neque. Donec eu ligula mi. Nam cursus vulputate semper. Phasellus facilisis mollis tellus, interdum laoreet justo rutrum pulvinar. Praesent molestie, nibh sed ultrices porttitor, nulla tortor volutpat enim, quis auctor est sem et orci. Proin lacinia vestibulum ex ut convallis. Phasellus tempus odio purus.</p>

<ul>
<li>Nam lacinia urna eu arcu auctor, eget euismod metus sagittis.</li>
<li>Etiam eleifend ex eu interdum varius.</li>
<li>Nunc dapibus purus eu felis tincidunt, vel rhoncus erat tristique.</li>
<li>Aenean nec augue sit amet lorem blandit ultrices.</li>
<li>Nullam at lacus eleifend, pulvinar velit tempor, auctor nisi.</li>
</ul>

<p>Nunc accumsan tincidunt augue sed blandit. Duis et dignissim nisi. Phasellus sed ligula velit. Etiam rhoncus aliquet magna, nec volutpat nulla imperdiet et. Nunc vel tincidunt magna. Vestibulum lacinia odio a metus placerat maximus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam et faucibus neque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean et metus malesuada, ullamcorper dui vel, convallis est. Donec congue libero sed turpis porta consequat. Suspendisse potenti. Aliquam pharetra nibh in magna iaculis, non elementum ipsum luctus.</p>', '1', '8');


INSERT INTO pages_description (`page_description_id`, `name`, `description`, `language_id`, `page_id`); VALUES ('23', 'Cookies', '<h2><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong></h2>

<p><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong></p>

<p>Cras non justo sed nulla finibus pulvinar sit amet et neque. Duis et odio vitae orci mattis gravida. Nullam vel tincidunt ex. Praesent vel neque egestas arcu feugiat venenatis. Donec eget dolor quis justo tempus mattis. Phasellus dictum nunc ut dapibus dictum. Etiam vel leo nulla. Ut eu mi hendrerit, eleifend lacus sed, dictum neque.</p>

<p>Aliquam non convallis nibh. Donec luctus purus magna, et commodo urna fermentum sed. Cras vel ex blandit, pretium nulla id, efficitur massa. Suspendisse potenti. Maecenas vel vehicula velit. Etiam quis orci molestie, elementum nisl eget, ultricies felis. Ut condimentum quam ut mi scelerisque accumsan. Suspendisse potenti. Etiam orci purus, iaculis sit amet ornare sit amet, finibus sed ligula. Quisque et mollis libero, sit amet consectetur augue. Vestibulum posuere pellentesque enim, in facilisis diam dictum eget. Phasellus sed vestibulum urna, in aliquet felis. Vivamus quis lacus id est ornare faucibus at id nulla.</p>

<h2>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</h2>

<p>Nulla justo lectus, sollicitudin at lorem eu, sollicitudin molestie augue. Maecenas egestas facilisis dolor mattis feugiat. Donec sed orci tellus. Maecenas tortor ipsum, varius vel dolor nec, bibendum porttitor felis. Mauris rutrum tristique vehicula. Sed ullamcorper nisl non erat pharetra, sit amet mattis enim posuere. Nulla convallis fringilla tortor, at vestibulum mauris cursus eget. Ut semper sollicitudin odio, sed molestie libero luctus quis. Integer viverra rutrum diam non maximus. Maecenas pellentesque tortor et sapien fermentum laoreet non et est. Phasellus felis quam, laoreet rhoncus erat eget, tempor condimentum massa. Integer gravida turpis id suscipit bibendum. Phasellus pellentesque venenatis erat, ut maximus justo vulputate sed. Vestibulum maximus enim ligula, non suscipit lectus dignissim vel. Suspendisse eleifend lorem egestas, tristique ligula id, condimentum est.</p>

<p>Mauris nulla nulla, laoreet at auctor quis, bibendum rutrum neque. Donec eu ligula mi. Nam cursus vulputate semper. Phasellus facilisis mollis tellus, interdum laoreet justo rutrum pulvinar. Praesent molestie, nibh sed ultrices porttitor, nulla tortor volutpat enim, quis auctor est sem et orci. Proin lacinia vestibulum ex ut convallis. Phasellus tempus odio purus.</p>

<ul>
<li>Nam lacinia urna eu arcu auctor, eget euismod metus sagittis.</li>
<li>Etiam eleifend ex eu interdum varius.</li>
<li>Nunc dapibus purus eu felis tincidunt, vel rhoncus erat tristique.</li>
<li>Aenean nec augue sit amet lorem blandit ultrices.</li>
<li>Nullam at lacus eleifend, pulvinar velit tempor, auctor nisi.</li>
</ul>

<p>Nunc accumsan tincidunt augue sed blandit. Duis et dignissim nisi. Phasellus sed ligula velit. Etiam rhoncus aliquet magna, nec volutpat nulla imperdiet et. Nunc vel tincidunt magna. Vestibulum lacinia odio a metus placerat maximus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam et faucibus neque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean et metus malesuada, ullamcorper dui vel, convallis est. Donec congue libero sed turpis porta consequat. Suspendisse potenti. Aliquam pharetra nibh in magna iaculis, non elementum ipsum luctus.</p>', '1', '9');


TRUNCATE payment_description; INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('1', '1', 'Braintree', '1', 'Credit Card', 'Paypal');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('4', '2', 'Stripe', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('5', '3', 'Paypal', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('6', '4', 'Cash on Delivery', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('7', '5', 'Instamojo', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('8', '0', 'Cybersoure', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('9', '6', 'Hyperpay', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('10', '7', 'Razor Pay', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('11', '8', 'PayTm', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('12', '8', 'Lorum Epsum', '2', '', '');


TRUNCATE payment_methods; INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('1', 'braintree', '1', '0', '2019-09-19 02:40:13', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('2', 'stripe', '1', '0', '2019-09-19 02:56:17', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('3', 'paypal', '1', '0', '2019-09-19 02:56:04', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('4', 'cash_on_delivery', '1', '0', '2019-09-19 02:56:37', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('5', 'instamojo', '1', '0', '2019-09-19 02:57:23', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('6', 'hyperpay', '1', '0', '2019-09-19 02:56:44', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('7', 'razor_pay', '1', '0', '2019-09-19 02:56:44', '0000-00-00 00:00:00');


INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('8', 'pay_tm', '1', '0', '2019-09-19 02:56:44', '0000-00-00 00:00:00');


TRUNCATE payment_methods_detail; INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('3', '1', 'merchant_id', 'wrv3cwbft6n3bg5g');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('4', '1', 'public_key', '2bz5kxcj2gs3hdbx');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('5', '1', 'private_key', '55ae08cb061e36dca59aaf2a883190bf');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('9', '2', 'secret_key', 'sk_test_Gsz7jL4wRikI8YFaNzbwxKOF');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('10', '2', 'publishable_key', 'pk_test_cCAEC6EejawuAvsvR9bhKrGR');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('15', '3', 'id', 'AULJ0Q_kdXwEbi7PCBunUBJc4Kkg2vvdazF8kJoywAV9_i7iJMQphB9NLwdR0v2BAUlLF974iTrynbys');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('18', '3', 'payment_currency', 'USD');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('21', '5', 'api_key', 'c5a348bd5fcb4c866074c48e9c77c6c4');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('22', '5', 'auth_token', '99448897defb4423b921fe47e0851b86');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('23', '5', 'client_id', 'test_9l7MW8I7c2bwIw7q0koc6B1j5NrvzyhasQh');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('24', '5', 'client_secret', 'test_m9Ey3Jqp9AfmyWKmUMktt4K3g1uMIdapledVRRYJha7WinxOsBVV5900QMlwvv3l2zRmzcYDEOKPh1cvnVedkAKtHOFFpJbqcoNCNrjx1FtZhtDMkEJFv9MJuXD');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('32', '6', 'userid', '8a82941865340dc8016537cdac1e0841');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('33', '6', 'password', 'sXrYy8pnsf');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('34', '6', 'entityid', '8a82941865340dc8016537ce08db0845');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('35', '7', 'RAZORPAY_KEY', 'rzp_test_izyMwtDZYAQeSA');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('36', '7', 'RAZORPAY_SECRET', 'LBIgacPG7Da6mdOARfig205j');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('37', '8', 'paytm_mid', 'QROqBU67944622696360');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('39', '8', 'paytm_key', 'w#5bJEFYV5EU4vnP');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('40', '8', 'current_domain_name', '');


TRUNCATE permissions; TRUNCATE products; TRUNCATE products_attributes; TRUNCATE products_description; TRUNCATE products_images; TRUNCATE products_options; TRUNCATE products_options_descriptions; TRUNCATE products_options_values; TRUNCATE products_options_values_descriptions; TRUNCATE products_shipping_rates; INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('1', '0', '10', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('2', '10', '20', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('3', '20', '30', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('4', '30', '50', '50', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('5', '50', '100000', '70', '1', '1');


TRUNCATE products_to_categories; TRUNCATE reviews; TRUNCATE reviews_description; TRUNCATE sessions; TRUNCATE settings; INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('1', 'facebook_app_id', 'FB_CLIENT_ID', '2018-04-27 10:00:00', '2019-11-01 16:58:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('2', 'facebook_secret_id', 'FB_SECRET_KEY', '2018-04-27 10:00:00', '2019-11-01 16:58:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('3', 'facebook_login', '1', '2018-04-27 10:00:00', '2019-11-01 16:58:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('4', 'contact_us_email', 'vectorcoder@gmail.com', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('5', 'address', 'address', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('6', 'city', 'City', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('7', 'state', 'State', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('8', 'zip', 'Zip', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('9', 'country', 'Country', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('10', 'latitude', 'Latitude', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('11', 'longitude', 'Longitude', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('12', 'phone_no', '+92 312 1234567', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('13', 'fcm_android', '', '2018-04-27 10:00:00', '2019-02-05 22:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('14', 'fcm_ios', '', '2018-04-27 10:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('15', 'fcm_desktop', '', '2018-04-27 10:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('16', 'website_logo', 'images/admin_logo/logo-laravel-blue-v1.png', '2018-04-27 10:00:00', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('17', 'fcm_android_sender_id', '', '2018-04-27 10:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('18', 'fcm_ios_sender_id', '', '2018-04-27 10:00:00', '2019-02-05 22:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('19', 'app_name', 'Da-viruz Systems', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('20', 'currency_symbol', '$', '2018-04-27 10:00:00', '2018-11-19 18:26:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('21', 'new_product_duration', '20', '2018-04-27 10:00:00', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('22', 'notification_title', 'Ionic Ecommerce', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('23', 'notification_text', 'A bundle of products waiting for you!', '2018-04-27 10:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('24', 'lazzy_loading_effect', 'Detail', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('25', 'footer_button', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('26', 'cart_button', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('27', 'featured_category', '', '2018-04-27 10:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('28', 'notification_duration', 'year', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('29', 'home_style', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('30', 'wish_list_page', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('31', 'edit_profile_page', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('32', 'shipping_address_page', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('33', 'my_orders_page', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('34', 'contact_us_page', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('35', 'about_us_page', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('36', 'news_page', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('37', 'intro_page', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('38', 'setting_page', '1', '2018-04-27 10:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('39', 'share_app', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('40', 'rate_app', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('41', 'site_url', 'URL', '2018-04-27 10:00:00', '2018-11-19 18:26:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('42', 'admob', '0', '2018-04-27 10:00:00', '2019-05-15 20:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('43', 'admob_id', 'ID', '2018-04-27 10:00:00', '2019-05-15 20:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('44', 'ad_unit_id_banner', 'Unit ID', '2018-04-27 10:00:00', '2019-05-15 20:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('45', 'ad_unit_id_interstitial', 'Indestrial', '2018-04-27 10:00:00', '2019-05-15 20:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('46', 'category_style', '4', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('47', 'package_name', 'package name', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('48', 'google_analytic_id', 'test', '2018-04-27 10:00:00', '2019-05-15 20:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('49', 'themes', 'themeone', '2018-04-27 10:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('50', 'company_name', '#', '2018-04-27 10:00:00', '2019-10-07 19:52:24');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('51', 'facebook_url', '#', '2018-04-27 10:00:00', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('52', 'google_url', '#', '2018-04-27 10:00:00', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('53', 'twitter_url', '#', '2018-04-27 10:00:00', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('54', 'linked_in', '#', '2018-04-27 10:00:00', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('55', 'default_notification', 'onesignal', '2018-04-27 10:00:00', '2019-02-05 22:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('56', 'onesignal_app_id', '6053d948-b8f6-472a-87e4-379fa89f78d8', '2018-04-27 10:00:00', '2019-02-05 22:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('57', 'onesignal_sender_id', '50877237723', '2018-04-27 10:00:00', '2019-02-05 22:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('58', 'ios_admob', '1', '2018-04-27 10:00:00', '2019-05-15 20:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('59', 'ios_admob_id', 'AdMob ID', '2018-04-27 10:00:00', '2019-05-15 20:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('60', 'ios_ad_unit_id_banner', 'Unit ID Banner', '2018-04-27 10:00:00', '2019-05-15 20:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('61', 'ios_ad_unit_id_interstitial', 'ID Interstitial', '2018-04-27 10:00:00', '2019-05-15 20:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('62', 'google_login', '1', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('63', 'google_app_id', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('64', 'google_secret_id', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('65', 'google_callback_url', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('66', 'facebook_callback_url', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('67', 'is_app_purchased', '0', '', '2018-05-04 13:24:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('68', 'is_web_purchased', '0', '', '2018-05-04 13:24:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('69', 'consumer_key', 'dadb7a7c1557917902724bbbf5', '', '2019-05-15 20:58:22');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('70', 'consumer_secret', '3ba77f821557917902b1d57373', '', '2019-05-15 20:58:22');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('71', 'order_email', 'orders@gmail.com', '', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('72', 'website_themes', '1', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('73', 'seo_title', '', '', '2018-11-19 18:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('74', 'seo_metatag', '', '', '2018-11-19 18:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('75', 'seo_keyword', '', '', '2018-11-19 18:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('76', 'seo_description', '', '', '2018-11-19 18:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('77', 'before_head_tag', '', '', '2018-11-19 18:22:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('78', 'end_body_tag', 'name', '', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('79', 'sitename_logo', 'ECommerce', '', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('80', 'website_name', '<strong>E</strong>COMMERCE', '', '2018-11-19 18:22:25');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('81', 'web_home_pages_style', 'two', '', '2018-11-19 18:22:25');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('82', 'web_color_style', 'app', '', '2018-11-19 18:22:25');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('83', 'free_shipping_limit', '400', '', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('84', 'app_icon_image', 'icon', '', '2019-02-05 21:12:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('85', 'twilio_status', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('86', 'twilio_authy_api_id', '1213213', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('87', 'favicon', 'images/admin_logo/logo-laravel-blue-v1.png', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('88', 'Thumbnail_height', '150', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('89', 'Thumbnail_width', '150', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('90', 'Medium_height', '400', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('91', 'Medium_width', '400', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('92', 'Large_height', '900', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('93', 'Large_width', '900', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('94', 'environmentt', 'local', '', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('95', 'maintenance_text', 'https://example.com', '', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('96', 'package_charge_taxt', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('97', 'order_commission', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('98', 'all_items_price_included_tax', 'yes', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('99', 'all_items_price_included_tax_value', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('100', 'driver_accept_multiple_order', '1', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('101', 'min_order_price', '100', '', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('102', 'youtube_link', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('103', 'external_website_link', 'http://localhost/laravel/public/', '', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('104', 'google_map_api', '', '', '2019-10-21 17:36:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('105', 'is_pos_purchased', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('106', 'admin_version', '4.0.12', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('107', 'app_version', '4.0.12', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('108', 'web_version', '4.0.12', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('109', 'pos_version', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('110', 'android_app_link', '#', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('111', 'iphone_app_link', '#', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('112', 'about_content', 'Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum', '', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('113', 'contact_content', 'Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum', '', '2019-10-11 21:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('114', 'contents', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('115', 'fb_redirect_url', 'http://YOUR_DOMAIN_NAME/login/facebook/callback', '', '2019-11-01 16:58:53');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('116', 'google_client_id', 'GOOGLE_CLIENT_ID', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('117', 'google_client_secret', 'GOOGLE_SECRET_KEY', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('118', 'google_redirect_url', 'http://YOUR_DOMAIN_NAME/login/google/callback', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('119', 'newsletter', '1', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('120', 'allow_cookies', '1', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('121', 'card_style', '1', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('122', 'banner_style', '1', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('123', 'mail_chimp_api', '', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('124', 'mail_chimp_list_id', '', '', '2019-11-01 16:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('125', 'newsletter_image', 'images/media/2019/10/newsletter.jpg', '', '2019-11-01 16:58:36');


TRUNCATE shipping_description; INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('1', 'Free Shipping', '1', 'free_shipping', '');


INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('4', 'Local Pickup', '1', 'local_pickup', '');


INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('7', 'Flat Rate', '1', 'flate_rate', '');


INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('10', 'UPS Shipping', '1', 'ups_shipping', '{\"nextDayAir\":\"Next Day Air\",\"secondDayAir\":\"2nd Day Air\",\"ground\":\"Ground\",\"threeDaySelect\":\"3 Day Select\",\"nextDayAirSaver\":\"Next Day AirSaver\",\"nextDayAirEarlyAM\":\"Next Day Air Early A.M.\",\"secondndDayAirAM\":\"2nd Day Air A.M.\"}');


INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('13', 'Shipping Price', '1', 'shipping_by_weight', '');


TRUNCATE shipping_methods; INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('1', 'upsShipping', '0', '0', 'ups_shipping');


INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('2', 'freeShipping', '0', '0', 'free_shipping');


INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('3', 'localPickup', '0', '0', 'local_pickup');


INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('4', 'flateRate', '1', '1', 'flate_rate');


INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('5', 'shippingByWeight', '0', '1', 'shipping_by_weight');


TRUNCATE sliders_images; INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('1', 'ewgrege', '#', '5', '16', '', '', '2020-07-08 00:00:00', '2019-09-08 18:44:49', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('2', 'frgergege', '#', '5', '17', '', '', '2020-10-14 00:00:00', '2019-09-08 18:45:10', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('3', 'dgdthrh', '#', '5', '18', '', '', '2019-09-18 00:00:00', '2019-09-08 18:45:40', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('4', 'sdasdasdass', '', '1', '111', '', '', '2020-07-15 00:00:00', '2019-09-10 08:26:49', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('5', 'fdsfds', '', '1', '111', '', '', '2020-08-14 00:00:00', '2019-09-10 08:27:04', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('6', 'fsfsfsfss', '', '1', '111', '', '', '2030-01-30 00:00:00', '2019-09-10 08:27:21', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('7', 'fdssdfsf', '', '2', '108', '', '', '2020-11-19 00:00:00', '2019-09-10 08:28:18', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('8', 'dasdada', '', '2', '108', '', '', '2021-07-14 00:00:00', '2019-09-10 08:28:31', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('9', 'dad', '', '2', '108', '', '', '2020-06-24 00:00:00', '2019-09-10 08:28:49', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('10', 'daadsd', '', '3', '110', '', '', '2021-10-20 00:00:00', '2019-09-10 08:29:41', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('11', 'sasdasd', '', '3', '110', '', '', '2020-07-15 00:00:00', '2019-09-10 08:29:58', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('12', 'ewef', '', '3', '110', '', '', '2021-07-15 00:00:00', '2019-09-10 08:30:13', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('13', 'fvtrgr', '', '4', '109', '', '', '2021-06-15 00:00:00', '2019-09-10 12:29:16', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('14', 't4tt', '', '4', '109', '', '', '2021-10-25 00:00:00', '2019-09-10 12:29:33', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('15', '4t4t4', '', '4', '109', '', '', '2022-07-07 00:00:00', '2019-09-10 12:29:50', '1', 'product', '', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('16', 'ewgrege', '#', '5', '16', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('17', 'frgergege', '#', '5', '17', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('18', 'dgdthrh', '#', '5', '18', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('19', 'sdasdasdass', '', '1', '111', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('20', 'fdsfds', '', '1', '111', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('21', 'fsfsfsfss', '', '1', '111', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('22', 'fdssdfsf', '', '2', '108', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('23', 'dasdada', '', '2', '108', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('24', 'dad', '', '2', '108', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('25', 'daadsd', '', '3', '110', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('26', 'sasdasd', '', '3', '110', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('27', 'ewef', '', '3', '110', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('28', 'fvtrgr', '', '4', '109', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('29', 't4tt', '', '4', '109', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('30', '4t4t4', '', '4', '109', '', '', '0000-00-00 00:00:00', '2019-10-11 06:51:42', '1', 'product', '', '2');


TRUNCATE specials; TRUNCATE tax_class; TRUNCATE tax_rates; TRUNCATE top_offers; TRUNCATE units; INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('1', '1', '', '', '2019-01-01 19:04:18', '2019-01-01 19:04:18');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('2', '1', '', '', '2019-01-01 19:04:18', '2019-01-01 19:04:18');


TRUNCATE units_descriptions; INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('1', 'Gram', '1', '1', '2019-01-01 19:04:18', '2019-01-01 19:04:18');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('2', 'غرام', '2', '1', '2019-01-01 19:04:18', '2019-01-01 19:04:18');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('3', 'Kilogram', '1', '2', '2019-01-01 19:04:18', '2019-01-01 19:04:18');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('4', 'كيلوغرام', '2', '2', '2019-01-01 19:04:18', '2019-01-01 19:04:18');


TRUNCATE ups_shipping; INSERT INTO ups_shipping (`ups_id`, `pickup_method`, `isDisplayCal`, `serviceType`, `shippingEnvironment`, `user_name`, `access_key`, `password`, `person_name`, `company_name`, `phone_number`, `address_line_1`, `address_line_2`, `country`, `state`, `post_code`, `city`, `no_of_package`, `parcel_height`, `parcel_width`, `title`); VALUES ('1', '07', '', 'US_01,US_02,US_03,US_12,US_13,US_14,US_59', '0', 'nyblueprint', 'FCD7C8F94CB5EF46', 'delfia11', '', '', '', 'D Ground', '', 'US', 'NY', '10312', 'New York City', '', '', '', '');


TRUNCATE user_to_address; TRUNCATE user_types; INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('1', 'Super Admin', '1534774230', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('2', 'Customers', '1534777027', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('3', 'Vendors', '1538390209', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('4', 'Delivery Guy', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('5', 'Test 1', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('6', 'Test 2', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('7', 'Test 3', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('8', 'Test 4', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('9', 'Test 5', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('10', 'Test 6', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('11', 'مضيفي البيانات', '1590631189', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('12', 'البائعون', '1590631226', '', '1');


TRUNCATE users; INSERT INTO users (`id`, `role_id`, `user_name`, `first_name`, `last_name`, `gender`, `default_address_id`, `country_code`, `phone`, `email`, `password`, `avatar`, `status`, `is_seen`, `phone_verified`, `remember_token`, `auth_id_tiwilo`, `dob`, `created_at`, `updated_at`); VALUES ('1', '1', 'Avinash', 'Uriah', 'Avinash', '', '0', '', '', 'avinash@gmail.com', '$2y$10$qH6UNuqh8diJRydJDhIbXur0JbDN4OoaxrrIH8rBbAjjT6I8nm1qi', '', '1', '0', '', '', '', '', '2020-05-18 15:12:52', '2020-05-18 15:12:52');


INSERT INTO users (`id`, `role_id`, `user_name`, `first_name`, `last_name`, `gender`, `default_address_id`, `country_code`, `phone`, `email`, `password`, `avatar`, `status`, `is_seen`, `phone_verified`, `remember_token`, `auth_id_tiwilo`, `dob`, `created_at`, `updated_at`); VALUES ('2', '2', '', 'Atamps', 'Yuri', '1', '0', '', '', 'atamps@gmail.com', '$2y$10$qH6UNuqh8diJRydJDhIbXur0JbDN4OoaxrrIH8rBbAjjT6I8nm1qi', '', '1', '1', '', '', '', '', '2020-05-18 15:57:08', '2020-05-18 15:57:08');


TRUNCATE whos_online; TRUNCATE zones; INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('1', '223', 'AL', 'Alabama');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('2', '223', 'AK', 'Alaska');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('3', '223', 'AS', 'American Samoa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('4', '223', 'AZ', 'Arizona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('5', '223', 'AR', 'Arkansas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('6', '223', 'AF', 'Armed Forces Africa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('7', '223', 'AA', 'Armed Forces Americas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('8', '223', 'AC', 'Armed Forces Canada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('9', '223', 'AE', 'Armed Forces Europe');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('10', '223', 'AM', 'Armed Forces Middle East');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('11', '223', 'AP', 'Armed Forces Pacific');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('12', '223', 'CA', 'California');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('13', '223', 'CO', 'Colorado');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('14', '223', 'CT', 'Connecticut');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('15', '223', 'DE', 'Delaware');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('16', '223', 'DC', 'District of Columbia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('17', '223', 'FM', 'Federated States Of Micronesia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('18', '223', 'FL', 'Florida');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('19', '223', 'GA', 'Georgia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('20', '223', 'GU', 'Guam');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('21', '223', 'HI', 'Hawaii');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('22', '223', 'ID', 'Idaho');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('23', '223', 'IL', 'Illinois');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('24', '223', 'IN', 'Indiana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('25', '223', 'IA', 'Iowa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('26', '223', 'KS', 'Kansas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('27', '223', 'KY', 'Kentucky');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('28', '223', 'LA', 'Louisiana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('29', '223', 'ME', 'Maine');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('30', '223', 'MH', 'Marshall Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('31', '223', 'MD', 'Maryland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('32', '223', 'MA', 'Massachusetts');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('33', '223', 'MI', 'Michigan');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('34', '223', 'MN', 'Minnesota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('35', '223', 'MS', 'Mississippi');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('36', '223', 'MO', 'Missouri');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('37', '223', 'MT', 'Montana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('38', '223', 'NE', 'Nebraska');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('39', '223', 'NV', 'Nevada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('40', '223', 'NH', 'New Hampshire');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('41', '223', 'NJ', 'New Jersey');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('42', '223', 'NM', 'New Mexico');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('43', '223', 'NY', 'New York');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('44', '223', 'NC', 'North Carolina');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('45', '223', 'ND', 'North Dakota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('46', '223', 'MP', 'Northern Mariana Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('47', '223', 'OH', 'Ohio');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('48', '223', 'OK', 'Oklahoma');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('49', '223', 'OR', 'Oregon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('50', '223', 'PW', 'Palau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('51', '223', 'PA', 'Pennsylvania');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('52', '223', 'PR', 'Puerto Rico');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('53', '223', 'RI', 'Rhode Island');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('54', '223', 'SC', 'South Carolina');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('55', '223', 'SD', 'South Dakota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('56', '223', 'TN', 'Tennessee');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('57', '223', 'TX', 'Texas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('58', '223', 'UT', 'Utah');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('59', '223', 'VT', 'Vermont');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('60', '223', 'VI', 'Virgin Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('61', '223', 'VA', 'Virginia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('62', '223', 'WA', 'Washington');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('63', '223', 'WV', 'West Virginia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('64', '223', 'WI', 'Wisconsin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('65', '223', 'WY', 'Wyoming');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('66', '38', 'AB', 'Alberta');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('67', '38', 'BC', 'British Columbia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('68', '38', 'MB', 'Manitoba');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('69', '38', 'NF', 'Newfoundland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('70', '38', 'NB', 'New Brunswick');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('71', '38', 'NS', 'Nova Scotia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('72', '38', 'NT', 'Northwest Territories');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('73', '38', 'NU', 'Nunavut');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('74', '38', 'ON', 'Ontario');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('75', '38', 'PE', 'Prince Edward Island');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('76', '38', 'QC', 'Quebec');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('77', '38', 'SK', 'Saskatchewan');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('78', '38', 'YT', 'Yukon Territory');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('79', '81', 'NDS', 'Niedersachsen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('80', '81', 'BAW', 'Baden-Württemberg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('81', '81', 'BAY', 'Bayern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('82', '81', 'BER', 'Berlin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('83', '81', 'BRG', 'Brandenburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('84', '81', 'BRE', 'Bremen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('85', '81', 'HAM', 'Hamburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('86', '81', 'HES', 'Hessen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('87', '81', 'MEC', 'Mecklenburg-Vorpommern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('88', '81', 'NRW', 'Nordrhein-Westfalen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('89', '81', 'RHE', 'Rheinland-Pfalz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('90', '81', 'SAR', 'Saarland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('91', '81', 'SAS', 'Sachsen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('92', '81', 'SAC', 'Sachsen-Anhalt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('93', '81', 'SCN', 'Schleswig-Holstein');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('94', '81', 'THE', 'Thüringen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('95', '14', 'WI', 'Wien');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('96', '14', 'NO', 'Niederösterreich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('97', '14', 'OO', 'Oberösterreich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('98', '14', 'SB', 'Salzburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('99', '14', 'KN', 'Kärnten');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('100', '14', 'ST', 'Steiermark');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('101', '14', 'TI', 'Tirol');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('102', '14', 'BL', 'Burgenland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('103', '14', 'VB', 'Voralberg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('104', '204', 'AG', 'Aargau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('105', '204', 'AI', 'Appenzell Innerrhoden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('106', '204', 'AR', 'Appenzell Ausserrhoden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('107', '204', 'BE', 'Bern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('108', '204', 'BL', 'Basel-Landschaft');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('109', '204', 'BS', 'Basel-Stadt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('110', '204', 'FR', 'Freiburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('111', '204', 'GE', 'Genf');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('112', '204', 'GL', 'Glarus');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('113', '204', 'JU', 'Graubünden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('114', '204', 'JU', 'Jura');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('115', '204', 'LU', 'Luzern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('116', '204', 'NE', 'Neuenburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('117', '204', 'NW', 'Nidwalden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('118', '204', 'OW', 'Obwalden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('119', '204', 'SG', 'St. Gallen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('120', '204', 'SH', 'Schaffhausen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('121', '204', 'SO', 'Solothurn');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('122', '204', 'SZ', 'Schwyz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('123', '204', 'TG', 'Thurgau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('124', '204', 'TI', 'Tessin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('125', '204', 'UR', 'Uri');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('126', '204', 'VD', 'Waadt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('127', '204', 'VS', 'Wallis');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('128', '204', 'ZG', 'Zug');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('129', '204', 'ZH', 'Zürich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('130', '195', 'A Coruña', 'A Coruña');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('131', '195', 'Alava', 'Alava');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('132', '195', 'Albacete', 'Albacete');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('133', '195', 'Alicante', 'Alicante');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('134', '195', 'Almeria', 'Almeria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('135', '195', 'Asturias', 'Asturias');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('136', '195', 'Avila', 'Avila');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('137', '195', 'Badajoz', 'Badajoz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('138', '195', 'Baleares', 'Baleares');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('139', '195', 'Barcelona', 'Barcelona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('140', '195', 'Burgos', 'Burgos');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('141', '195', 'Caceres', 'Caceres');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('142', '195', 'Cadiz', 'Cadiz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('143', '195', 'Cantabria', 'Cantabria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('144', '195', 'Castellon', 'Castellon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('145', '195', 'Ceuta', 'Ceuta');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('146', '195', 'Ciudad Real', 'Ciudad Real');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('147', '195', 'Cordoba', 'Cordoba');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('148', '195', 'Cuenca', 'Cuenca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('149', '195', 'Girona', 'Girona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('150', '195', 'Granada', 'Granada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('151', '195', 'Guadalajara', 'Guadalajara');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('152', '195', 'Guipuzcoa', 'Guipuzcoa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('153', '195', 'Huelva', 'Huelva');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('154', '195', 'Huesca', 'Huesca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('155', '195', 'Jaen', 'Jaen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('156', '195', 'La Rioja', 'La Rioja');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('157', '195', 'Las Palmas', 'Las Palmas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('158', '195', 'Leon', 'Leon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('159', '195', 'Lleida', 'Lleida');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('160', '195', 'Lugo', 'Lugo');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('161', '195', 'Madrid', 'Madrid');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('162', '195', 'Malaga', 'Malaga');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('163', '195', 'Melilla', 'Melilla');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('164', '195', 'Murcia', 'Murcia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('165', '195', 'Navarra', 'Navarra');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('166', '195', 'Ourense', 'Ourense');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('167', '195', 'Palencia', 'Palencia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('168', '195', 'Pontevedra', 'Pontevedra');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('169', '195', 'Salamanca', 'Salamanca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('170', '195', 'Santa Cruz de Tenerife', 'Santa Cruz de Tenerife');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('171', '195', 'Segovia', 'Segovia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('172', '195', 'Sevilla', 'Sevilla');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('173', '195', 'Soria', 'Soria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('174', '195', 'Tarragona', 'Tarragona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('175', '195', 'Teruel', 'Teruel');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('176', '195', 'Toledo', 'Toledo');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('177', '195', 'Valencia', 'Valencia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('178', '195', 'Valladolid', 'Valladolid');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('179', '195', 'Vizcaya', 'Vizcaya');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('180', '195', 'Zamora', 'Zamora');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('181', '195', 'Zaragoza', 'Zaragoza');


TRUNCATE zones_to_geo_zones; 